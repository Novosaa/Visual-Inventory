using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace VisualInventory.Views;

/// <summary>True → hidden, false → shown. Used for "+ Add note" links that disappear once a note is open.</summary>
public sealed class InverseVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is true ? Visibility.Collapsed : Visibility.Visible;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
