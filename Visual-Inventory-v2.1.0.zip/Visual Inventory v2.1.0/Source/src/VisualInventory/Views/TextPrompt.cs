using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace VisualInventory.Views;

/// <summary>Small "type a name" dialog used for new and renamed categories and the project name.</summary>
public static class TextPrompt
{
    public static string? Ask(Window owner, string title, string message, string initial)
    {
        var box = new TextBox { Text = initial, Height = 32, Padding = new Thickness(7, 5, 7, 5), Margin = new Thickness(0, 8, 0, 16), VerticalContentAlignment = VerticalAlignment.Center };
        var ok = new Button { Content = "OK", Width = 90, Height = 32, IsDefault = true, Margin = new Thickness(0, 0, 8, 0) };
        var cancel = new Button { Content = "Cancel", Width = 90, Height = 32, IsCancel = true };
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        buttons.Children.Add(ok);
        buttons.Children.Add(cancel);

        var panel = new StackPanel { Margin = new Thickness(20) };
        panel.Children.Add(new TextBlock { Text = message, TextWrapping = TextWrapping.Wrap, Foreground = new SolidColorBrush(Color.FromRgb(0x20, 0x1D, 0x22)) });
        panel.Children.Add(box);
        panel.Children.Add(buttons);

        var dialog = new Window
        {
            Title = title,
            Content = panel,
            Owner = owner,
            Width = 420,
            SizeToContent = SizeToContent.Height,
            ResizeMode = ResizeMode.NoResize,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            ShowInTaskbar = false
        };
        ok.Click += (_, _) => dialog.DialogResult = true;
        dialog.Loaded += (_, _) => { box.Focus(); box.SelectAll(); Keyboard.Focus(box); };
        return dialog.ShowDialog() == true ? box.Text.Trim() : null;
    }
}
