using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using VisualInventory.Services;

namespace VisualInventory;

public partial class App : Application
{
    public static ProjectPaths Paths { get; } = new(AppContext.BaseDirectory);

    protected override void OnStartup(StartupEventArgs e)
    {
        DispatcherUnhandledException += OnUiException;
        AppDomain.CurrentDomain.UnhandledException += (_, args) => WriteErrorLog(args.ExceptionObject as Exception);
        TaskScheduler.UnobservedTaskException += (_, args) => { WriteErrorLog(args.Exception); args.SetObserved(); };
        base.OnStartup(e);
    }

    private void OnUiException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        WriteErrorLog(e.Exception);
        MessageBox.Show(
            "Something went wrong, but your files were not changed.\n\n" + e.Exception.Message +
            "\n\nDetails were saved to Inventory Data\\error-log.txt.",
            "Visual Inventory", MessageBoxButton.OK, MessageBoxImage.Warning);
        e.Handled = true;
    }

    public static void WriteErrorLog(Exception? exception)
    {
        if (exception is null) return;
        try
        {
            Paths.EnsureDataFolder();
            File.AppendAllText(Paths.ErrorLogFile, $"---- {DateTime.Now:yyyy-MM-dd HH:mm:ss} ----{Environment.NewLine}{exception}{Environment.NewLine}");
        }
        catch { /* never let error logging cause another error */ }
    }
}
