using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace VisualInventory.Models;

public sealed class WorkspaceSnapshot
{
    public required string LibraryPath { get; init; }
    public DateTime ScannedAt { get; init; } = DateTime.Now;
    public int SourceFileCount { get; set; }
    public List<WorkspaceItem> Items { get; } = [];
    public List<SectionSummary> Sections { get; } = [];
}

public sealed class SectionSummary
{
    public required string Name { get; init; }
    public required string Accent { get; init; }
    /// <summary>Real folder for this category, or null for the virtual "Unsorted" group of loose files.</summary>
    public string? FolderPath { get; init; }
    public int ItemCount { get; init; }
    public bool IsRealFolder => FolderPath is not null;
    public string CountText => $"{ItemCount} item{(ItemCount == 1 ? string.Empty : "s")}";
}

public sealed class WorkspaceItem : INotifyPropertyChanged
{
    private bool _isSelected;
    private string _userNote = string.Empty;
    private bool _noteOpen;
    private bool _todoOpen;

    public required string Id { get; init; }
    public required string Section { get; init; }
    public required string Title { get; init; }
    public required string PrimaryPath { get; init; }
    public required string RelativePath { get; init; }
    public string LibraryLocation => "Library" + Path.DirectorySeparatorChar + RelativePath;
    public string FileName { get; init; } = string.Empty;
    public string Kind { get; init; } = "File";
    /// <summary>Short label shown when there is no picture, e.g. "PDF", "HTML", "FOLDER".</summary>
    public string TypeLabel { get; init; } = "FILE";
    public string? PreviewPath { get; init; }
    public bool HasPreview => PreviewPath is not null;
    public bool IsDirectory { get; init; }
    public int SourceFileCount { get; init; } = 1;

    public string SubText => IsDirectory
        ? $"Folder · {SourceFileCount} file{(SourceFileCount == 1 ? string.Empty : "s")}"
        : Kind;

    public bool IsSelected
    {
        get => _isSelected;
        set { if (_isSelected == value) return; _isSelected = value; OnPropertyChanged(); }
    }

    // ---- your own note and to-do list for this item (hidden until you add one)

    public string UserNote
    {
        get => _userNote;
        set { var v = value ?? string.Empty; if (_userNote == v) return; _userNote = v; OnPropertyChanged(); }
    }

    public ObservableCollection<TodoItem> Todos { get; } = [];

    /// <summary>The note box is shown once you choose "Add note", or when a saved note exists.</summary>
    public bool NoteOpen
    {
        get => _noteOpen;
        set { if (_noteOpen == value) return; _noteOpen = value; OnPropertyChanged(); }
    }

    /// <summary>The to-do list is shown once you choose "Add to-do list", or when saved items exist.</summary>
    public bool TodoOpen
    {
        get => _todoOpen;
        set { if (_todoOpen == value) return; _todoOpen = value; OnPropertyChanged(); }
    }

    public bool HasNotes => !string.IsNullOrWhiteSpace(UserNote) || Todos.Count > 0;

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

public sealed class TodoItem : INotifyPropertyChanged
{
    private string _text = string.Empty;
    private bool _done;

    public string Text
    {
        get => _text;
        set { var v = value ?? string.Empty; if (_text == v) return; _text = v; OnPropertyChanged(); }
    }

    public bool Done
    {
        get => _done;
        set { if (_done == value) return; _done = value; OnPropertyChanged(); }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

/// <summary>What is saved for one item: your note and your to-do list.</summary>
public sealed class ItemNotes
{
    public string? Note { get; set; }
    public List<SavedTodo> Todos { get; set; } = [];
}

public sealed class SavedTodo
{
    public string Text { get; set; } = string.Empty;
    public bool Done { get; set; }
}

public sealed class NotesState
{
    public int Version { get; set; } = 1;
    public Dictionary<string, ItemNotes> Items { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class ProjectSettings
{
    public string? Name { get; set; }
}

public sealed class WindowPlacement
{
    public double Left { get; set; }
    public double Top { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }
    public bool Maximized { get; set; }
    public double DetailsWidth { get; set; } = 330;
    public bool DetailsVisible { get; set; } = true;
}

public sealed class ImportResult
{
    public List<string> Copied { get; } = [];
    public List<string> Failed { get; } = [];
}
