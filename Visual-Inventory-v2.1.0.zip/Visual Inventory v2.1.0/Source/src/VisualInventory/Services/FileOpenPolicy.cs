namespace VisualInventory.Services;

/// <summary>
/// Decides which files "Open" may hand to Windows. Anything that could run a program
/// (.exe, .bat, scripts, shortcuts, installers and every unknown type) is never opened;
/// the app shows it in Explorer instead.
/// </summary>
public static class FileOpenPolicy
{
    private static readonly HashSet<string> SafeExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        // images
        ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tif", ".tiff", ".ico", ".heic", ".avif",
        // documents and text
        ".pdf", ".txt", ".md", ".csv", ".rtf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
        ".odt", ".ods", ".odp", ".json", ".xml",
        // web pages open in your browser, which keeps them sandboxed
        ".html", ".htm", ".svg", ".css",
        // design files
        ".psd", ".ai", ".eps", ".indd", ".afdesign", ".afphoto", ".afpub", ".xcf", ".kra", ".sketch", ".fig",
        // fonts open in the Windows font viewer
        ".ttf", ".otf", ".woff", ".woff2",
        // media
        ".mp4", ".mov", ".m4v", ".webm", ".avi", ".mp3", ".wav", ".m4a",
        // archives open in Explorer, they are not extracted or run
        ".zip"
    };

    public static bool CanOpenDirectly(string path)
    {
        if (Directory.Exists(path)) return true;
        return SafeExtensions.Contains(Path.GetExtension(path));
    }
}
