namespace VisualInventory.Services;

/// <summary>Plain-text record of every change the app makes to files, kept in Inventory Data.</summary>
public sealed class ActivityLog(ProjectPaths paths)
{
    public void Write(string action, string detail)
    {
        try
        {
            paths.EnsureDataFolder();
            File.AppendAllText(paths.ActivityLogFile, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}  {action,-16} {detail}{Environment.NewLine}");
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            // Logging must never stop the user's action. A read-only drive simply has no log.
        }
    }
}
