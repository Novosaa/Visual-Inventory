using System.Text.RegularExpressions;
using VisualInventory.Models;

namespace VisualInventory.Services;

/// <summary>
/// Reads the Library folder. Every direct folder is a category; every direct file or
/// folder inside a category is one item. Loose files at the top of Library appear in a
/// virtual "Unsorted" group. Nothing is classified or renamed.
/// </summary>
public sealed class ProjectScanner
{
    public const string UnsortedName = "Unsorted";
    public static readonly string[] PreviewExtensions = [".jpg", ".jpeg", ".png", ".bmp", ".gif"];
    private static readonly string[] Accents = ["#E85D91", "#4CB7BF", "#8CBF67", "#E9C84A", "#D9845F", "#9B83C9", "#62AC91", "#648FCA", "#C982A2"];

    public WorkspaceSnapshot Scan(string libraryPath)
    {
        var library = Path.GetFullPath(libraryPath);
        if (!Directory.Exists(library)) throw new DirectoryNotFoundException("The Library folder was not found next to the app.");

        var snapshot = new WorkspaceSnapshot
        {
            LibraryPath = library,
            SourceFileCount = SafeFiles(library, SearchOption.AllDirectories).Count
        };

        var categories = SafeDirectories(library)
            .Where(path => !IsHiddenName(Path.GetFileName(path)))
            .OrderBy(Path.GetFileName, StringComparer.CurrentCultureIgnoreCase)
            .ToList();

        foreach (var categoryPath in categories)
        {
            var section = Path.GetFileName(categoryPath);
            foreach (var entry in SafeEntries(categoryPath).Where(p => !IsHiddenName(Path.GetFileName(p))))
                snapshot.Items.Add(BuildItem(library, section, entry));
        }

        foreach (var loose in SafeTopFiles(library).Where(p => !IsHiddenName(Path.GetFileName(p))))
            snapshot.Items.Add(BuildItem(library, UnsortedName, loose));

        var index = 0;
        foreach (var categoryPath in categories)
            snapshot.Sections.Add(MakeSection(snapshot, Path.GetFileName(categoryPath), categoryPath, index++));

        var hasRealUnsorted = categories.Any(path => Path.GetFileName(path).Equals(UnsortedName, StringComparison.OrdinalIgnoreCase));
        if (!hasRealUnsorted && snapshot.Items.Any(item => item.Section == UnsortedName))
            snapshot.Sections.Add(MakeSection(snapshot, UnsortedName, null, index));

        return snapshot;
    }

    /// <summary>Item IDs (used to keep notes with an item) are built from its path inside Library.</summary>
    public static string MakeId(string relativePath) => "stored:" + Slug(relativePath);

    private static SectionSummary MakeSection(WorkspaceSnapshot snapshot, string name, string? folder, int index)
    {
        var items = snapshot.Items.Where(item => item.Section.Equals(name, StringComparison.OrdinalIgnoreCase)).ToList();
        return new SectionSummary
        {
            Name = name,
            FolderPath = folder,
            Accent = Accents[index % Accents.Length],
            ItemCount = items.Count
        };
    }

    private static WorkspaceItem BuildItem(string library, string section, string path)
    {
        var isDirectory = Directory.Exists(path);
        var files = isDirectory ? SafeFiles(path, SearchOption.AllDirectories) : [path];
        var name = Path.GetFileName(path);
        var extension = Path.GetExtension(name);
        var preview = isDirectory
            ? files.Where(IsPreviewImage).OrderBy(f => f, StringComparer.CurrentCultureIgnoreCase).FirstOrDefault()
            : IsPreviewImage(path) ? path : null;
        var title = Humanize(isDirectory ? name : Path.GetFileNameWithoutExtension(name));
        var relative = Path.GetRelativePath(library, path);

        return new WorkspaceItem
        {
            Id = MakeId(relative),
            Section = section,
            Title = string.IsNullOrWhiteSpace(title) ? name : title,
            FileName = name,
            PrimaryPath = path,
            RelativePath = relative,
            IsDirectory = isDirectory,
            Kind = isDirectory ? "Folder" : string.IsNullOrWhiteSpace(extension) ? "File" : extension.TrimStart('.').ToUpperInvariant() + " file",
            TypeLabel = isDirectory ? "FOLDER" : string.IsNullOrWhiteSpace(extension) ? "FILE" : extension.TrimStart('.').ToUpperInvariant(),
            PreviewPath = preview,
            SourceFileCount = files.Count
        };
    }

    private static bool IsHiddenName(string? name) => string.IsNullOrEmpty(name) || name.StartsWith('.') || name.Equals("desktop.ini", StringComparison.OrdinalIgnoreCase) || name.Equals("Thumbs.db", StringComparison.OrdinalIgnoreCase);
    public static bool IsPreviewImage(string path) => PreviewExtensions.Contains(Path.GetExtension(path), StringComparer.OrdinalIgnoreCase);

    private static List<string> SafeEntries(string folder)
    {
        try { return Directory.EnumerateFileSystemEntries(folder).Where(p => !PathRules.IsLink(p)).ToList(); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return []; }
    }

    private static List<string> SafeDirectories(string folder)
    {
        try { return Directory.EnumerateDirectories(folder).Where(p => !PathRules.IsLink(p)).ToList(); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return []; }
    }

    private static List<string> SafeTopFiles(string folder)
    {
        try { return Directory.EnumerateFiles(folder).Where(p => !PathRules.IsLink(p)).ToList(); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return []; }
    }

    /// <summary>Lists files without following linked folders (junctions/symlinks) anywhere in the tree.</summary>
    private static List<string> SafeFiles(string folder, SearchOption option)
    {
        var result = new List<string>();
        var pending = new Stack<string>();
        pending.Push(folder);
        while (pending.Count > 0)
        {
            var current = pending.Pop();
            result.AddRange(SafeTopFiles(current));
            if (option == SearchOption.AllDirectories)
                foreach (var child in SafeDirectories(current)) pending.Push(child);
        }
        return result;
    }

    private static string Humanize(string value) => Regex.Replace(value.Replace('_', ' ').Replace('-', ' '), @"\s+", " ").Trim();
    private static string Slug(string value) => Regex.Replace(value.ToLowerInvariant(), "[^a-z0-9]+", "-").Trim('-');
}
