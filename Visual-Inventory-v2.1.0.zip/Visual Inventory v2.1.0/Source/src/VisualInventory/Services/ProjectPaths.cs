namespace VisualInventory.Services;

/// <summary>
/// Every path the app is allowed to use. A project is one folder:
///   [project]\VisualInventory.exe   (and its Runtime folder)
///   [project]\Library\              your categories and files
///   [project]\Inventory Data\       notes, to-do lists, settings, logs, backups
/// The app never chooses or browses any other library location.
/// </summary>
public sealed class ProjectPaths
{
    public const string LibraryFolderName = "Library";
    public const string DataFolderName = "Inventory Data";

    public ProjectPaths(string projectRoot)
    {
        Root = Path.GetFullPath(projectRoot).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        if (Root.EndsWith(':')) Root += Path.DirectorySeparatorChar; // drive root such as E:\
        LibraryPath = Path.Combine(Root, LibraryFolderName);
        DataPath = Path.Combine(Root, DataFolderName);
    }

    public string Root { get; }
    public string LibraryPath { get; }
    public string DataPath { get; }
    public string NotesFile => Path.Combine(DataPath, "notes.json");
    public string NotesBackupFile => Path.Combine(DataPath, "notes.backup.json");
    public string SettingsFile => Path.Combine(DataPath, "project.json");
    public string WindowFile => Path.Combine(DataPath, "window.json");
    public string ActivityLogFile => Path.Combine(DataPath, "activity-log.txt");
    public string ErrorLogFile => Path.Combine(DataPath, "error-log.txt");

    public bool LibraryExists => Directory.Exists(LibraryPath);

    public string DefaultProjectName
    {
        get
        {
            var name = Path.GetFileName(Root.TrimEnd(Path.DirectorySeparatorChar));
            return string.IsNullOrWhiteSpace(name) ? "My project" : name;
        }
    }

    public void EnsureDataFolder() => Directory.CreateDirectory(DataPath);

    /// <summary>True when <paramref name="candidate"/> is the library folder itself or anything inside it.</summary>
    public bool IsInsideLibrary(string candidate) => PathRules.IsSameOrInside(LibraryPath, candidate);
}

public static class PathRules
{
    public static bool IsSameOrInside(string folder, string candidate)
    {
        var relative = Path.GetRelativePath(Path.GetFullPath(folder), Path.GetFullPath(candidate));
        if (relative == ".") return true;
        return !relative.Equals("..", StringComparison.Ordinal)
               && !relative.StartsWith(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal)
               && !relative.StartsWith(".." + Path.AltDirectorySeparatorChar, StringComparison.Ordinal)
               && !Path.IsPathRooted(relative);
    }

    public static bool IsStrictlyInside(string folder, string candidate) =>
        IsSameOrInside(folder, candidate) && !SamePath(folder, candidate);

    public static bool SamePath(string left, string right) =>
        string.Equals(
            Path.GetFullPath(left).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
            Path.GetFullPath(right).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
            StringComparison.OrdinalIgnoreCase);

    public static bool IsLink(string path)
    {
        try { return (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0; }
        catch { return true; }
    }
}
