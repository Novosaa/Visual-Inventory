namespace VisualInventory.Services;

/// <summary>
/// The only code that changes files. Rules:
///  - every destination must be inside the project's Library folder;
///  - adding files always COPIES; originals outside the Library are never moved or changed;
///  - moving is only allowed between categories inside the Library;
///  - nothing is ever deleted;
///  - every change is written to the activity log.
/// </summary>
public sealed class LibraryService(ProjectPaths paths, ActivityLog log)
{
    public string CreateCategory(string name)
    {
        var clean = ValidateName(name);
        var path = Path.Combine(paths.LibraryPath, clean);
        if (Directory.Exists(path) || File.Exists(path)) throw new IOException($"A category named '{clean}' already exists.");
        Directory.CreateDirectory(path);
        log.Write("NEW CATEGORY", clean);
        return path;
    }

    public string RenameCategory(string currentFolder, string newName)
    {
        RequireInsideLibrary(currentFolder);
        if (!Directory.Exists(currentFolder)) throw new DirectoryNotFoundException("That category folder no longer exists. Press Refresh.");
        var clean = ValidateName(newName);
        var oldName = Path.GetFileName(currentFolder);
        if (clean == oldName) return currentFolder;
        var destination = Path.Combine(paths.LibraryPath, clean);

        if (clean.Equals(oldName, StringComparison.OrdinalIgnoreCase))
        {
            // Windows ignores letter case in names, so a case-only rename needs a temporary step.
            var temporary = Path.Combine(paths.LibraryPath, $"{clean}.renaming-{Guid.NewGuid():N}");
            Directory.Move(currentFolder, temporary);
            Directory.Move(temporary, destination);
        }
        else
        {
            if (Directory.Exists(destination) || File.Exists(destination)) throw new IOException($"A category named '{clean}' already exists.");
            Directory.Move(currentFolder, destination);
        }

        log.Write("RENAME CATEGORY", $"{oldName}  ->  {clean}");
        return destination;
    }

    /// <summary>Copies files or folders into a category. Each item succeeds or fails on its own.</summary>
    public Models.ImportResult ImportCopies(IEnumerable<string> sourcePaths, string categoryFolder)
    {
        RequireInsideLibrary(categoryFolder);
        if (PathRules.SamePath(categoryFolder, paths.LibraryPath)) throw new IOException("Open a category first. Files are added into a category, not the top of the Library.");
        Directory.CreateDirectory(categoryFolder);
        var result = new Models.ImportResult();

        foreach (var source in sourcePaths.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var name = Path.GetFileName(source.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
            string? target = null;
            try
            {
                if (!File.Exists(source) && !Directory.Exists(source)) throw new FileNotFoundException("It no longer exists.");
                if (PathRules.IsSameOrInside(source, categoryFolder)) throw new IOException("A folder cannot be copied into itself.");
                if (PathRules.IsSameOrInside(categoryFolder, source)) throw new IOException("It is already in this category.");
                if (PathRules.IsLink(source)) throw new IOException("Linked folders and shortcuts to other locations are not copied.");

                target = UniqueDestination(categoryFolder, name);
                if (Directory.Exists(source)) CopyDirectory(source, target);
                else CopyFileVerified(source, target);

                log.Write("COPY IN", $"{source}  ->  {Path.GetRelativePath(paths.LibraryPath, target)}");
                result.Copied.Add(target);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException)
            {
                // A folder that failed part-way is left as it is (nothing is ever deleted), and the message says so.
                if (target is not null && Directory.Exists(target))
                {
                    var partial = Path.GetRelativePath(paths.LibraryPath, target);
                    log.Write("COPY PARTLY", $"{source}  ->  {partial}  ({ex.Message})");
                    result.Failed.Add($"{name}: only partly copied, as {partial}. Check it before relying on it. ({ex.Message})");
                }
                else
                {
                    log.Write("COPY FAILED", $"{source}  ({ex.Message})");
                    result.Failed.Add($"{name}: {ex.Message}");
                }
            }
        }
        return result;
    }

    /// <summary>Moves one stored item to another category. Both places must be inside the Library.</summary>
    public string MoveToCategory(string itemPath, string destinationCategoryFolder)
    {
        RequireInsideLibrary(itemPath);
        RequireInsideLibrary(destinationCategoryFolder);
        if (PathRules.SamePath(itemPath, paths.LibraryPath)) throw new IOException("The Library itself cannot be moved.");
        if (PathRules.SamePath(destinationCategoryFolder, paths.LibraryPath)) throw new IOException("Choose a category to move it into.");
        if (PathRules.IsSameOrInside(itemPath, destinationCategoryFolder)) throw new IOException("A folder cannot be moved into itself.");
        var parent = Path.GetDirectoryName(itemPath);
        if (parent is not null && PathRules.SamePath(parent, destinationCategoryFolder)) return itemPath;

        Directory.CreateDirectory(destinationCategoryFolder);
        var target = UniqueDestination(destinationCategoryFolder, Path.GetFileName(itemPath));
        if (Directory.Exists(itemPath)) Directory.Move(itemPath, target);
        else if (File.Exists(itemPath)) File.Move(itemPath, target);
        else throw new FileNotFoundException("That item no longer exists. Press Refresh.");

        log.Write("MOVE", $"{Path.GetRelativePath(paths.LibraryPath, itemPath)}  ->  {Path.GetRelativePath(paths.LibraryPath, target)}");
        return target;
    }

    private void RequireInsideLibrary(string path)
    {
        if (!paths.IsInsideLibrary(path))
            throw new UnauthorizedAccessException("Visual Inventory only changes files inside this project's Library folder.");
    }

    private static void CopyFileVerified(string source, string target)
    {
        File.Copy(source, target, overwrite: false);
        if (new FileInfo(source).Length != new FileInfo(target).Length)
            throw new IOException("The copy did not finish correctly. The original was not changed.");
    }

    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (var file in Directory.EnumerateFiles(source))
        {
            if (PathRules.IsLink(file)) continue;
            CopyFileVerified(file, Path.Combine(destination, Path.GetFileName(file)));
        }
        foreach (var directory in Directory.EnumerateDirectories(source))
        {
            if (PathRules.IsLink(directory)) continue;
            CopyDirectory(directory, Path.Combine(destination, Path.GetFileName(directory)));
        }
    }

    private static string UniqueDestination(string folder, string name)
    {
        var candidate = Path.Combine(folder, name);
        if (!File.Exists(candidate) && !Directory.Exists(candidate)) return candidate;
        var stem = Path.GetFileNameWithoutExtension(name);
        var extension = Path.GetExtension(name);
        for (var index = 2; index < 10_000; index++)
        {
            candidate = Path.Combine(folder, $"{stem} ({index}){extension}");
            if (!File.Exists(candidate) && !Directory.Exists(candidate)) return candidate;
        }
        throw new IOException($"No free name was found for '{name}'.");
    }

    public static string ValidateName(string name)
    {
        var clean = (name ?? string.Empty).Trim().TrimEnd('.');
        if (string.IsNullOrWhiteSpace(clean)) throw new InvalidDataException("Enter a category name.");
        if (clean.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || clean.IndexOfAny(['\\', '/', ':', '*', '?', '"', '<', '>', '|']) >= 0)
            throw new InvalidDataException("That name has characters Windows can't use in a folder name ( \\ / : * ? \" < > | ).");
        if (clean.StartsWith('.')) throw new InvalidDataException("Category names can't start with a dot.");
        var reserved = new[] { "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9" };
        if (reserved.Contains(Path.GetFileNameWithoutExtension(clean), StringComparer.OrdinalIgnoreCase))
            throw new InvalidDataException("That name is reserved by Windows. Choose another.");
        if (clean.Length > 120) throw new InvalidDataException("Keep the category name under 120 characters.");
        return clean;
    }
}
