using System.Text.Json;
using VisualInventory.Models;

namespace VisualInventory.Services;

/// <summary>
/// Saves your notes, to-do lists, project settings and window placement inside the project's
/// Inventory Data folder, so they travel with the project. Every save of notes keeps the
/// previous version as a backup, and a damaged file is set aside rather than overwritten.
/// </summary>
public sealed class StateStore(ProjectPaths paths)
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    /// <summary>Set when the saved notes could not be read and a backup or fresh start was used.</summary>
    public string? LoadWarning { get; private set; }

    public NotesState LoadNotes()
    {
        LoadWarning = null;
        if (!File.Exists(paths.NotesFile)) return new NotesState();
        if (TryRead<NotesState>(paths.NotesFile, out var state)) return IgnoreCase(state);

        var setAside = SetAsideDamagedFile(paths.NotesFile);
        if (File.Exists(paths.NotesBackupFile) && TryRead<NotesState>(paths.NotesBackupFile, out var backup))
        {
            LoadWarning = $"The saved notes file could not be read, so the last backup was used instead.\n\nThe damaged file was kept as:\n{setAside}";
            return IgnoreCase(backup);
        }

        LoadWarning = $"The saved notes could not be read and no usable backup was found. Notes start empty.\n\nThe damaged file was kept as:\n{setAside}";
        return new NotesState();
    }

    /// <summary>
    /// Reading notes.json loses the "ignore letter case" setting of the list (Windows names ignore case),
    /// so it is put back here. Before 2.1.2 this didn't matter because the old IDs were always lower case.
    /// </summary>
    private static NotesState IgnoreCase(NotesState state)
    {
        var items = new Dictionary<string, ItemNotes>(StringComparer.OrdinalIgnoreCase);
        foreach (var (key, value) in state.Items ?? []) items[key] = value;
        state.Items = items;
        return state;
    }

    /// <summary>
    /// Notes saved by 2.1.1 or earlier use the old simplified ID. Each such note is copied onto every item
    /// that had that old ID (so nothing that was showing before disappears), saved under the item's new ID,
    /// and the old entry removed. Notes for items no longer in the Library are left as they are.
    /// Returns true when anything was carried over, so the caller can save.
    /// </summary>
    public static bool CarryOverOldNotes(WorkspaceSnapshot snapshot, NotesState state)
    {
        var carried = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in snapshot.Items)
        {
            if (state.Items.ContainsKey(item.Id)) continue;
            var legacy = ProjectScanner.LegacyId(item.RelativePath);
            if (!state.Items.TryGetValue(legacy, out var old)) continue;
            state.Items[item.Id] = new ItemNotes
            {
                Note = old.Note,
                Todos = old.Todos.Select(t => new SavedTodo { Text = t.Text, Done = t.Done }).ToList()
            };
            carried.Add(legacy);
        }
        foreach (var legacy in carried) state.Items.Remove(legacy);
        return carried.Count > 0;
    }

    /// <summary>Puts saved notes and to-do lists onto the items just read from the Library.</summary>
    public static void Apply(WorkspaceSnapshot snapshot, NotesState state)
    {
        foreach (var item in snapshot.Items)
        {
            if (!state.Items.TryGetValue(item.Id, out var saved)) continue;
            item.UserNote = saved.Note ?? string.Empty;
            item.Todos.Clear();
            foreach (var todo in saved.Todos.Where(t => !string.IsNullOrWhiteSpace(t.Text)))
                item.Todos.Add(new TodoItem { Text = todo.Text, Done = todo.Done });
            item.NoteOpen = !string.IsNullOrWhiteSpace(item.UserNote);
            item.TodoOpen = item.Todos.Count > 0;
        }
    }

    /// <summary>Copies the current notes and to-do lists from the items into the saved state, then saves.</summary>
    public void SaveNotes(WorkspaceSnapshot snapshot, NotesState state)
    {
        foreach (var item in snapshot.Items)
        {
            var todos = item.Todos.Where(t => !string.IsNullOrWhiteSpace(t.Text))
                                  .Select(t => new SavedTodo { Text = t.Text.Trim(), Done = t.Done }).ToList();
            var note = string.IsNullOrWhiteSpace(item.UserNote) ? null : item.UserNote;
            if (note is null && todos.Count == 0) state.Items.Remove(item.Id);
            else state.Items[item.Id] = new ItemNotes { Note = note, Todos = todos };
        }
        WriteNotes(state);
    }

    /// <summary>Saves the notes exactly as they are (used after a move or rename, before re-reading the Library).</summary>
    public void WriteNotes(NotesState state) => WriteWithBackup(paths.NotesFile, paths.NotesBackupFile, state);

    /// <summary>Keeps an item's notes when its path changes (moved, or its category was renamed).</summary>
    public static void MoveEntry(NotesState state, string oldId, string newId)
    {
        if (oldId.Equals(newId, StringComparison.OrdinalIgnoreCase)) return;
        if (!state.Items.Remove(oldId, out var saved)) return;
        state.Items[newId] = saved;
    }

    public ProjectSettings LoadSettings() =>
        File.Exists(paths.SettingsFile) && TryRead<ProjectSettings>(paths.SettingsFile, out var settings) ? settings : new ProjectSettings();

    public void SaveSettings(ProjectSettings settings) => WriteAtomic(paths.SettingsFile, settings);

    public WindowPlacement? LoadWindow() =>
        File.Exists(paths.WindowFile) && TryRead<WindowPlacement>(paths.WindowFile, out var placement) ? placement : null;

    public void SaveWindow(WindowPlacement placement)
    {
        try { WriteAtomic(paths.WindowFile, placement); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { /* read-only drive: just don't remember */ }
    }

    private void WriteWithBackup<T>(string file, string backup, T value) where T : class
    {
        paths.EnsureDataFolder();
        var temporary = file + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(value, JsonOptions));
        if (File.Exists(file) && TryRead<T>(file, out _)) File.Copy(file, backup, overwrite: true);
        File.Move(temporary, file, overwrite: true);
    }

    private void WriteAtomic<T>(string file, T value)
    {
        paths.EnsureDataFolder();
        var temporary = file + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(value, JsonOptions));
        File.Move(temporary, file, overwrite: true);
    }

    private static bool TryRead<T>(string file, out T value) where T : class
    {
        try
        {
            var parsed = JsonSerializer.Deserialize<T>(File.ReadAllText(file), JsonOptions);
            if (parsed is not null) { value = parsed; return true; }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException or NotSupportedException) { }
        value = null!;
        return false;
    }

    private static string SetAsideDamagedFile(string file)
    {
        var target = Path.Combine(Path.GetDirectoryName(file)!, $"{Path.GetFileNameWithoutExtension(file)}.unreadable-{DateTime.Now:yyyyMMdd-HHmmss}.json");
        try { File.Move(file, target); return target; }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return file; }
    }
}
