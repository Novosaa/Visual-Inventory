using VisualInventory.Models;
using VisualInventory.Services;

// Exercises every file-changing rule against a throwaway test folder.
if (args.Length != 1) { Console.Error.WriteLine("Usage: VisualInventory.Tests <empty-test-folder>"); return 2; }

var testRoot = Path.GetFullPath(args[0]);
if (Directory.Exists(testRoot)) Directory.Delete(testRoot, recursive: true);
var projectRoot = Path.Combine(testRoot, "My Project");
var outside = Path.Combine(testRoot, "outside");
Directory.CreateDirectory(projectRoot);
Directory.CreateDirectory(outside);

var failures = new List<string>();
void Check(bool ok, string message) { if (!ok) failures.Add(message); }

var paths = new ProjectPaths(projectRoot);
var log = new ActivityLog(paths);
var library = new LibraryService(paths, log);
var store = new StateStore(paths);
var scanner = new ProjectScanner();

Check(!paths.LibraryExists, "Library should not exist before it is created.");
Directory.CreateDirectory(paths.LibraryPath);
Check(paths.DefaultProjectName == "My Project", "Project name should come from the folder name.");

// --- categories
var ads = library.CreateCategory("4-Ads");
var adsBlank = library.CreateCategory("4-Ads-Blank");
var covers = library.CreateCategory("1-Card Covers");
Check(Directory.Exists(ads) && Directory.Exists(covers), "Categories were not created.");
foreach (var bad in new[] { "", "  ", "a/b", "a\\b", "..", "CON", ".hidden", "x:y" })
{
    try { library.CreateCategory(bad); failures.Add($"Bad category name was accepted: '{bad}'"); }
    catch (Exception ex) when (ex is InvalidDataException or IOException) { }
}
try { library.CreateCategory("4-Ads"); failures.Add("Duplicate category was accepted."); } catch (IOException) { }

// --- copy in (originals untouched)
var picture = Path.Combine(outside, "card-front.png");
File.WriteAllBytes(picture, [137, 80, 78, 71, 1, 2, 3]);
var pdf = Path.Combine(outside, "stocklist.pdf");
File.WriteAllText(pdf, "pdf placeholder");
var folder = Path.Combine(outside, "Bundle");
Directory.CreateDirectory(Path.Combine(folder, "inner"));
File.WriteAllText(Path.Combine(folder, "inner", "a.txt"), "a");
File.WriteAllText(Path.Combine(folder, "notes.txt"), "Folder note text");
File.WriteAllBytes(Path.Combine(folder, "cover.jpg"), [1, 2]);

var result = library.ImportCopies([picture, pdf, folder, Path.Combine(outside, "missing.png")], ads);
Check(result.Copied.Count == 3, $"Expected 3 copies, got {result.Copied.Count}.");
Check(result.Failed.Count == 1, "Missing file should be reported, not crash.");
Check(File.Exists(picture) && File.Exists(pdf) && Directory.Exists(folder), "Originals must stay where they were.");
Check(File.Exists(Path.Combine(ads, "card-front.png")), "Copied picture missing.");
Check(File.Exists(Path.Combine(ads, "Bundle", "inner", "a.txt")), "Copied folder contents missing.");

var again = library.ImportCopies([picture], ads);
Check(File.Exists(Path.Combine(ads, "card-front (2).png")), "Name clash should create a numbered copy, never overwrite.");

// --- refuse anything outside the Library or into itself
try { library.ImportCopies([picture], outside); failures.Add("Copy into a folder outside the Library was allowed."); } catch (UnauthorizedAccessException) { }
try { library.ImportCopies([picture], paths.LibraryPath); failures.Add("Copy into the top of the Library was allowed."); } catch (IOException) { }
var self = library.ImportCopies([ads], Path.Combine(ads, "Bundle"));
Check(self.Failed.Count == 1, "Copying a folder into itself must be refused.");
try { library.MoveToCategory(picture, covers); failures.Add("Moving a file from outside the Library was allowed."); } catch (UnauthorizedAccessException) { }
try { library.MoveToCategory(Path.Combine(ads, "card-front.png"), outside); failures.Add("Moving out of the Library was allowed."); } catch (UnauthorizedAccessException) { }

// --- scan
File.WriteAllText(Path.Combine(paths.LibraryPath, "loose.txt"), "loose");
var snapshot = scanner.Scan(paths.LibraryPath);
Check(snapshot.Sections.Select(s => s.Name).SequenceEqual(["1-Card Covers", "4-Ads", "4-Ads-Blank", "Unsorted"]), "Categories should be the real folders plus Unsorted for loose files: " + string.Join(", ", snapshot.Sections.Select(s => s.Name)));
var png = snapshot.Items.Single(i => i.FileName == "card-front.png");
Check(png.HasPreview && png.TypeLabel == "PNG", "PNG should have a picture preview.");
var pdfItem = snapshot.Items.Single(i => i.FileName == "stocklist.pdf");
Check(!pdfItem.HasPreview && pdfItem.TypeLabel == "PDF", "PDF should show its type label, not a picture.");
var bundle = snapshot.Items.Single(i => i.FileName == "Bundle");
Check(bundle.IsDirectory && bundle.HasPreview, "Folder should use the first picture inside it.");
Check(png.Id == "path:4-Ads/card-front.png", "Unexpected item ID: " + png.Id);

// --- notes and to-do lists: hidden until added, saved, and they follow the item on move/rename
Check(!png.NoteOpen && !png.TodoOpen, "Note and to-do list should be hidden until added.");
png.UserNote = "Use this for the Valentine ad";
png.Todos.Add(new TodoItem { Text = "Resize for Etsy" });
png.Todos.Add(new TodoItem { Text = "Check colours", Done = true });
pdfItem.Todos.Add(new TodoItem { Text = "Update prices" });
var state = store.LoadNotes();
store.SaveNotes(snapshot, state);
Check(File.Exists(paths.NotesFile), "Notes were not saved inside Inventory Data.");
Check(state.Items.Count == 2, $"Only items with a note or to-do should be saved (got {state.Items.Count}).");

var movedPath = library.MoveToCategory(png.PrimaryPath, covers);
StateStore.MoveEntry(state, png.Id, ProjectScanner.MakeId(Path.GetRelativePath(paths.LibraryPath, movedPath)));
store.WriteNotes(state);

var adsItems = scanner.Scan(paths.LibraryPath).Items.Where(i => i.Section == "4-Ads").ToList();
var renamed = library.RenameCategory(ads, "4 Ads Final");
foreach (var item in adsItems)
{
    var inside = Path.GetRelativePath(ads, item.PrimaryPath);
    StateStore.MoveEntry(state, item.Id, ProjectScanner.MakeId(Path.GetRelativePath(paths.LibraryPath, Path.Combine(renamed, inside))));
}
store.WriteNotes(state);

var reread = scanner.Scan(paths.LibraryPath);
var fresh = store.LoadNotes();
StateStore.Apply(reread, fresh);
var movedPng = reread.Items.Single(i => i.FileName == "card-front.png");
Check(movedPng.UserNote == "Use this for the Valentine ad" && movedPng.NoteOpen, "Note was lost when the item was moved.");
Check(movedPng.Todos.Count == 2 && movedPng.Todos[1].Done && !movedPng.Todos[0].Done && movedPng.TodoOpen, "To-do list (or ticks) lost when the item was moved.");
var renamedPdf = reread.Items.Single(i => i.FileName == "stocklist.pdf");
Check(renamedPdf.Todos.Count == 1 && renamedPdf.TodoOpen && !renamedPdf.NoteOpen, "To-do list lost when the category was renamed, or an empty note was shown.");
Check(File.Exists(paths.NotesBackupFile), "A backup of the notes should be kept.");

// clearing a note and its list removes the saved entry
movedPng.UserNote = "";
movedPng.Todos.Clear();
store.SaveNotes(reread, fresh);
Check(!fresh.Items.ContainsKey(movedPng.Id), "An empty note/list should not be stored.");

// --- case-only rename
var caseRenamed = library.RenameCategory(renamed, "4 ADS FINAL");
Check(Directory.Exists(caseRenamed) && Path.GetFileName(caseRenamed) == "4 ADS FINAL", "Case-only rename failed.");

// --- damaged notes file is set aside, backup used
File.WriteAllText(paths.NotesFile, "{ this is not valid json");
var recovered = store.LoadNotes();
Check(store.LoadWarning is not null, "A damaged notes file should produce a warning.");
Check(recovered.Items.Count > 0, "The backup should be used when the notes file is damaged.");
Check(Directory.GetFiles(paths.DataPath, "notes.unreadable-*.json").Length == 1, "The damaged file should be kept, not overwritten.");

// --- nothing was ever deleted outside, log exists
Check(File.Exists(picture) && File.Exists(pdf), "Originals outside the Library were changed.");
Check(File.Exists(paths.ActivityLogFile) && File.ReadAllText(paths.ActivityLogFile).Contains("MOVE"), "Activity log is missing entries.");

// --- 2.1.2 fix: names that used to collide keep their own notes
var clash = library.CreateCategory("Clash");
File.WriteAllText(Path.Combine(clash, "image (1).png"), "a");
File.WriteAllText(Path.Combine(clash, "image 1.png"), "b");
var clashScan = scanner.Scan(paths.LibraryPath);
var imgA = clashScan.Items.Single(i => i.FileName == "image (1).png");
var imgB = clashScan.Items.Single(i => i.FileName == "image 1.png");
Check(imgA.Id != imgB.Id, "Two different file names must not share one ID: " + imgA.Id);
imgA.UserNote = "note for A";
var clashState = store.LoadNotes();
store.SaveNotes(clashScan, clashState);
var clashReread = scanner.Scan(paths.LibraryPath);
StateStore.Apply(clashReread, store.LoadNotes());
Check(clashReread.Items.Single(i => i.FileName == "image (1).png").UserNote == "note for A", "Note for 'image (1).png' was lost.");
Check(clashReread.Items.Single(i => i.FileName == "image 1.png").UserNote == "", "Note leaked onto 'image 1.png'.");

// --- 2.1.2 fix: the saved list ignores letter case after loading (Windows names ignore case)
var caseState = store.LoadNotes();
Check(caseState.Items.ContainsKey("PATH:CLASH/IMAGE (1).PNG"), "Saved notes should be found whatever the letter case.");

// --- 2.1.2: notes saved by 2.1.1 (old IDs) are carried over, nothing lost
var oldStyle = new NotesState();
oldStyle.Items["stored:clash-image-1-png"] = new ItemNotes { Note = "old shared note", Todos = [new SavedTodo { Text = "old task", Done = true }] };
oldStyle.Items["stored:gone-elsewhere-png"] = new ItemNotes { Note = "file no longer in Library" };
store.WriteNotes(oldStyle);
var legacyLoaded = store.LoadNotes();
var legacyScan = scanner.Scan(paths.LibraryPath);
Check(StateStore.CarryOverOldNotes(legacyScan, legacyLoaded), "Old notes should be carried over.");
StateStore.Apply(legacyScan, legacyLoaded);
foreach (var name in new[] { "image (1).png", "image 1.png" })
{
    var it = legacyScan.Items.Single(i => i.FileName == name);
    Check(it.UserNote == "old shared note" && it.Todos.Count == 1 && it.Todos[0].Done, $"Old note not carried over to '{name}'.");
}
Check(!legacyLoaded.Items.ContainsKey("stored:clash-image-1-png"), "Carried-over old entry should be replaced by the new ones.");
Check(legacyLoaded.Items.ContainsKey("stored:gone-elsewhere-png"), "Notes for files not in the Library must be kept, not dropped.");
Check(!StateStore.CarryOverOldNotes(legacyScan, legacyLoaded), "Carrying over should happen only once.");

// --- 2.1.2 fix: a real folder called "Unsorted" and the loose files stay separate
var realUnsorted = library.CreateCategory("Unsorted");
File.WriteAllText(Path.Combine(realUnsorted, "kept.txt"), "k");
var unsortedScan = scanner.Scan(paths.LibraryPath);
Check(unsortedScan.Items.Single(i => i.FileName == "kept.txt").Section == "Unsorted", "File in the real Unsorted folder is in the wrong category.");
Check(unsortedScan.Items.Single(i => i.FileName == "loose.txt").Section == ProjectScanner.LooseFilesName, "Loose files got mixed into the real Unsorted folder.");
Check(unsortedScan.Sections.Count(s => s.Name == "Unsorted") == 1 && unsortedScan.Sections.Single(s => s.Name == "Unsorted").IsRealFolder, "There should be exactly one Unsorted category, the real folder.");
Check(unsortedScan.Sections.Any(s => s.Name == ProjectScanner.LooseFilesName && !s.IsRealFolder), "Loose files should have their own group.");

// --- settings and window placement
store.SaveSettings(new ProjectSettings { Name = "Side Eye Series" });
Check(store.LoadSettings().Name == "Side Eye Series", "Project name was not saved.");
store.SaveWindow(new WindowPlacement { Left = 10, Top = 20, Width = 1000, Height = 700 });
Check(store.LoadWindow()?.Width == 1000, "Window size was not saved.");

if (failures.Count == 0) { Console.WriteLine("VISUAL INVENTORY 2.1.2 TESTS: PASS"); return 0; }
foreach (var failure in failures) Console.Error.WriteLine("FAIL: " + failure);
Console.Error.WriteLine("VISUAL INVENTORY 2.1.2 TESTS: FAIL");
return 1;
