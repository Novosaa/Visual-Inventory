# Visual Inventory: hand-off for a new thread

Written 21 Oct 2026 at the end of a long thread. Give this file to the new thread, along with
the zip(s) for the version you want to work on. The owner is not a developer: explain things
in plain words, without jargon or "everyone knows this" shortcuts. Not coding doesn't mean
not capable.

---

## 1. What this is

**Visual Inventory** is a small Windows app that shows what's stored in a folder *as pictures*:
images show as images, and other files show their type (PDF, JS, HTML...). It is not a file
manager and it is not a "scanner". Each folder inside the app's `Library` folder is a category
in the sidebar.

There are now **two separate apps (two "lines")**, and the owner wants to keep both:

| Line | Latest | What it is |
|---|---|---|
| **3.x: View only** | **3.0.3** | Only looks. Writes nothing anywhere. Can't open, move, copy, rename, add or delete anything. No notes or settings. Two versions: generic, and Side Eye Series. |
| **2.x: Organiser** | **2.1.1** | The older one. Can add files (copy only), drag-and-drop, move items between categories, make or rename categories, copy name/path, Show in Explorer, notes and to-do lists. Writes only inside its own project folder (`Library\` and `Inventory Data\`). |

Both: C# / .NET 10 (LTS) / WPF, `net10.0-windows`, `win-x64`. Each project is one self-contained
folder: the 4 app files, `Runtime\` (Microsoft's .NET 10.0.12, bundled), `Library\`, and in
2.x only `Inventory Data\`. The launcher only uses the bundled Runtime
(`AppHostDotNetSearch=AppRelative`, `AppHostRelativeDotNet=Runtime`).

---

## 2. The owner's rules (follow every one, every time)

1. **Read every file in full before changing it.** No skimming the top. Skipping this is
   skipping a required step, not "a shortcut".
2. **Write `DOCUMENTATION\ACTION-LOG.txt` step by step *while* working**, mistakes included,
   with times. Not afterwards. It's the builder's record, not proof.
3. **Don't add features nobody asked for.** Confirm the plan before big changes. If something
   small and unrequested slips in, say so and offer to remove it.
4. **Plain language.**
5. **Official sources only** when official sources are asked for (e.g. Microsoft). Keep
   non-official sources clearly separate.
6. **The app must not touch anything outside its own folder.** No Windows/shell thumbnails, no
   browser engine or HTML preview, no WebView2, no reading or importing from other apps, no
   pop-up questions (error messages only).
7. **Version numbers** use the 1.2.3 style, with a plain "what changed" line per version in
   READ ME FIRST.txt.
8. **Don't present your own tests or checks as independent proof.** The owner rejected
   self-run auditors and hooks. Say plainly when you're checking your own work.
9. It's a **"visual inventory"**, not a scanner. Internal code names like `ProjectScanner` stay.
10. **Don't gatekeep the owner's own data.** Only hold back live credentials.
11. **Stop when the owner stops a step,** and say exactly what did and didn't happen. Never
    describe a planned step as done.

---

## 3. Version history (plain)

- **1.3.0:** the original Side-Eye Visual Inventory (made by Codex).
- **2.0.0:** generic. One self-contained project folder; window fits the screen; scrolling
  sidebar; right-click menus; safety rules.
- **2.0.1:** removed importing from the old app and the confirmation questions.
- **2.0.2:** removed the sidebar's "New category" section; thin scroll bars.
- **2.1.0:** removed status labels and check boxes; tiles fill the width; file details; optional
  notes and to-do lists.
- **2.1.1:** removed every way of opening files in other programs. **← latest of the 2.x line.**
- **3.0.0:** view only (everything that could change, open, copy or save was removed).
  *Packaging mistake: the exe came from the wrong folder and asked for .NET to be installed.*
- **3.0.1:** same app, launcher fixed.
- **3.0.2:** the tile grid fixed (see the known bug below).
- **3.0.3:** new icons. The old eye icon is gone. Generic version = pink icon + pink sidebar
  badge. Side Eye Series version = the owner's logo as the icon (whole logo, uncropped) and as a
  banner at the top of the sidebar. **← latest of the 3.x line.**

---

## 4. How to build (both lines the same way)

**Files needed** (the owner downloads them from Microsoft and uploads them; the workspace can't
download from Microsoft or NuGet):
- `dotnet-sdk-10.0.401-linux-x64.tar.gz` (to build on Linux)
- `microsoft.windowsdesktop.app.ref.10.0.12.nupkg`
- `microsoft.netcore.app.host.win-x64.10.0.12.nupkg`
- and for running on the PC: `dotnet-runtime-10.0.12-win-x64.zip` and
  `windowsdesktop-runtime-10.0.12-win-x64.zip` (these go in via `SET UP RUNTIME.bat`, which
  checks Microsoft's SHA-512 checksums and unpacks them into `Runtime\`)

**Setup:** extract the SDK. Put the two `.nupkg` files in a local folder. Make a `NuGet.config`
whose only package source is that folder (`<clear />`, then one `<add>`). Copy it next to the
source while building and **delete it afterwards** so it doesn't end up in the package.

**Build:**
```
DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1
dotnet publish src/VisualInventory/VisualInventory.csproj -c Release -r win-x64 \
    --self-contained false -p:NuGetAudit=false --disable-build-servers -o <output folder>
```
- 3.x Side Eye version: add `-p:Brand=SideEye`.
- **Package ONLY from the `-o` publish output, never from `bin\Release\...`.** The exe in `bin` has
  no Runtime instruction, so it says .NET needs installing. That was the 3.0.0 mistake.
- **Check the exe inside the finished zip** for the Runtime instruction (the bytes `Runtime\0`)
  before sending.

**Tests (3.x):**
```
dotnet build tests/VisualInventory.Tests -c Release -o <testbin>
dotnet <testbin>/VisualInventory.Tests.dll <empty temp folder> <path to src/VisualInventory>
```
- Part 1 checks the reader.
- Part 2 checks that reading changes nothing on disk.
- Part 3 is the **isolation check**: it searches the app's code for 14 kinds of forbidden code
  (writing, copying, moving or deleting; write-mode file access; starting programs; clipboard;
  file boxes; internet; registry; system folders; direct Windows calls; saving; dropped files).
  It first proves it catches known-bad lines. As a control, run on 2.1.1's code it finds 30.
- **2.x tests** (`tests/VisualInventory.Tests`, different file) cover copy, move, notes and to-do
  saving. Its own BUILD.txt has the command. The isolation check does NOT apply to 2.x, which
  writes by design.

**Packaging layout** (per zip):
- `Starter Project\`: 4 app files, `SET UP RUNTIME.bat`, empty `Library\` and `Runtime\`
- `Source\`: `src\`, `tests\`, `BUILD.txt`, no `bin`/`obj`
- `READ ME FIRST.txt`
- `DOCUMENTATION\ACTION-LOG.txt` (Windows line endings)
- `CHECKSUMS-SHA256.txt`

The runtime is not included (the chat's 30 MB send limit).

You can't see the app run in the cloud workspace (Linux). **The owner's screenshot is the only
check of how it looks.** Say so each time.

---

## 5. Where things are in the code

```
src/VisualInventory/
  VisualInventory.csproj     build settings (version, icon, Runtime-only, 3.x Brand switch)
  App.xaml / App.xaml.cs     colours, thin scroll bars, startup, error message
  MainWindow.xaml(.cs)       the screen and what clicks do; UpdateTileSize = tile grid maths
  Models/WorkspaceModels.cs  what a category and an item are
  Services/ProjectPaths.cs   finds Library next to the exe
  Services/ProjectScanner.cs reads Library (categories = folders; loose files = "Unsorted")
  Views/FileDetails.cs       size, dates, dimensions (reads the picture header, read-only)
  Views/ThumbnailConverter.cs loads tile pictures read-only (OnLoad cache, files not locked)
  2.x only: Services/LibraryService.cs (copy/move/categories), StateStore.cs (notes,
            settings, window size, with backups), ActivityLog.cs, Views/TextPrompt.cs,
            Views/InverseVisibilityConverter.cs
  3.x only: Assets/SideEye.ico, Assets/SideEyeLogo.png (the owner's logo, unchanged),
            ApplyBrand() in MainWindow.xaml.cs
```

---

## 6. Known problems and open items

**2.x line (2.1.1):**
- **Tile grid bug, not fixed in 2.1.1.** `UpdateTileSize` leaves out the gap after the last tile,
  so one tile always wraps and rows show fewer tiles with empty space. **Fix it exactly as in
  3.0.2:**
  `available = ScrollerWidth - 28 - 20 - 8 - 2; columns = floor(available / (238 + 16)); width = floor(available / columns - 16)`
- **Still has the old eye icon.** If the owner wants the new icons on 2.x too, ask first.
- **Telling the two apps apart:** both are named "Visual Inventory" and both use
  `VisualInventory.exe`. If the owner wants them easier to tell apart (name or icon), ask
  first; don't decide for them.
- **The "keeps track of itself" question:** 2.x saves settings, window size, notes and logs in
  `Inventory Data\`. The owner questioned that before 3.0. Don't expand it without asking.

**Both lines:**
- **Startup hooks are not locked.** A PC setting could make the app load an extra DLL. One line
  locks it (`<StartupHookSupport>false</StartupHookSupport>`). Offered; the owner hasn't decided.
- **The isolation check (3.x) has a known gap:** `FileInfo.Replace(...)` looks like text
  `.Replace(...)`, so it isn't searched for. The app's only `Replace` is tidying names into
  titles (ProjectScanner.cs).
- **Nothing is code-signed.** Windows will say "unknown publisher". If double-clicking does
  nothing, the downloaded zip needs Unblock (Properties).

**Ideas the owner has seen but not chosen** (don't build without asking):
- Look inside folder items as tiles
- A bigger picture on click
- Arrow keys between tiles
- Sorting (session only)
- A `logo.png` read from the project folder instead of a built-in logo
- Colour settings via a `Look.txt` file
- A Windows Firewall rule blocking VisualInventory.exe (done by the owner, not code)

**Next project, not started:** "What's Running", a read-only viewer with tabs for running
programs, connections (which program, listening or outgoing, the other end, how long) and
startup items. Right-click to copy name/path/command line/row or search online. Plain-English
columns. Can't kill or change anything. Scope and name proposed, **not confirmed**.

---

## 7. Mistakes made last time (don't repeat)

- Overwrote files after reading only the first few lines.
- Added unrequested things: Windows thumbnails, cover images, a duplicate finder, an extra
  "New category" entry.
- Packaged the exe from `bin` instead of the publish output (3.0.0), and checked the DLL and
  source but never the exe itself.
- Tile maths missed the last gap (2.1.0 to 3.0.2).
- Said "being packaged" in the log before packaging had happened.
- Cropped the owner's logo when told not to.
- Held back the owner's own data (feature flags, settings) for no good reason.
