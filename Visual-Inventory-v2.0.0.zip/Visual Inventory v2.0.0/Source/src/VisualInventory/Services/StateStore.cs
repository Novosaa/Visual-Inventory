using System.Text.Json;
using VisualInventory.Models;

namespace VisualInventory.Services;

/// <summary>
/// Saves statuses, project settings and window placement inside the project's
/// Inventory Data folder, so they travel with the project. Every save keeps the
/// previous version as a backup, and a damaged file is set aside rather than overwritten.
/// </summary>
public sealed class StateStore(ProjectPaths paths)
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    /// <summary>Set when the saved statuses could not be read and a backup or fresh start was used.</summary>
    public string? LoadWarning { get; private set; }

    public WorkspaceState LoadStatuses()
    {
        LoadWarning = null;
        if (!File.Exists(paths.StateFile)) return new WorkspaceState();
        if (TryRead<WorkspaceState>(paths.StateFile, out var state)) return state;

        var setAside = SetAsideDamagedFile(paths.StateFile);
        if (File.Exists(paths.StateBackupFile) && TryRead<WorkspaceState>(paths.StateBackupFile, out var backup))
        {
            LoadWarning = $"The saved statuses file could not be read, so the last backup was used instead.\n\nThe damaged file was kept as:\n{setAside}";
            return backup;
        }

        LoadWarning = $"The saved statuses could not be read and no usable backup was found. Statuses start fresh.\n\nThe damaged file was kept as:\n{setAside}";
        return new WorkspaceState();
    }

    public void Apply(WorkspaceSnapshot snapshot, WorkspaceState state)
    {
        foreach (var item in snapshot.Items)
            if (state.Items.TryGetValue(item.Id, out var saved) && Statuses.All.Contains(saved.Status))
                item.Status = saved.Status;
    }

    public void SaveStatuses(WorkspaceSnapshot snapshot, WorkspaceState state)
    {
        foreach (var item in snapshot.Items)
        {
            if (item.Status == Statuses.NotStarted) state.Items.Remove(item.Id);
            else state.Items[item.Id] = new ItemState { Status = item.Status };
        }
        WriteWithBackup(paths.StateFile, paths.StateBackupFile, state);
    }

    /// <summary>Saves the statuses exactly as they are (used after a move or rename, before re-reading the Library).</summary>
    public void WriteStatuses(WorkspaceState state) => WriteWithBackup(paths.StateFile, paths.StateBackupFile, state);

    /// <summary>Keeps an item's status when its path changes (moved, or its category was renamed).</summary>
    public static void MoveEntry(WorkspaceState state, string oldId, string newId)
    {
        if (oldId.Equals(newId, StringComparison.OrdinalIgnoreCase)) return;
        if (!state.Items.Remove(oldId, out var saved)) return;
        state.Items[newId] = saved;
    }

    public ProjectSettings LoadSettings() =>
        File.Exists(paths.SettingsFile) && TryRead<ProjectSettings>(paths.SettingsFile, out var settings) ? settings : new ProjectSettings();

    public void SaveSettings(ProjectSettings settings) => WriteAtomic(paths.SettingsFile, settings);

    public WindowPlacement? LoadWindow() =>
        File.Exists(paths.WindowFile) && TryRead<WindowPlacement>(paths.WindowFile, out var placement) ? placement : null;

    public void SaveWindow(WindowPlacement placement)
    {
        try { WriteAtomic(paths.WindowFile, placement); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { /* read-only drive: just don't remember */ }
    }

    /// <summary>
    /// Reads (never changes) the statuses saved by the old Side-Eye Visual Inventory and returns
    /// the ones that match items in this Library and aren't already set here.
    /// </summary>
    public static Dictionary<string, string> FindOldStatuses(WorkspaceSnapshot snapshot, WorkspaceState current)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        try
        {
            var oldFile = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "SideEyeSeries", "VisualInventory", "workspace-state.json");
            if (!File.Exists(oldFile)) return result;

            using var document = JsonDocument.Parse(File.ReadAllText(oldFile));
            if (!document.RootElement.TryGetProperty("Items", out var items) || items.ValueKind != JsonValueKind.Object) return result;

            var ids = snapshot.Items.Select(item => item.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in items.EnumerateObject())
            {
                if (!ids.Contains(entry.Name) || current.Items.ContainsKey(entry.Name)) continue;
                if (!entry.Value.TryGetProperty("Status", out var statusElement)) continue;
                var status = statusElement.GetString();
                if (status is null || status == Statuses.NotStarted || !Statuses.All.Contains(status)) continue;
                result[entry.Name] = status;
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException or InvalidOperationException)
        {
            result.Clear();
        }
        return result;
    }

    private void WriteWithBackup<T>(string file, string backup, T value) where T : class
    {
        paths.EnsureDataFolder();
        var temporary = file + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(value, JsonOptions));
        if (File.Exists(file) && TryRead<T>(file, out _)) File.Copy(file, backup, overwrite: true);
        File.Move(temporary, file, overwrite: true);
    }

    private void WriteAtomic<T>(string file, T value)
    {
        paths.EnsureDataFolder();
        var temporary = file + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(value, JsonOptions));
        File.Move(temporary, file, overwrite: true);
    }

    private static bool TryRead<T>(string file, out T value) where T : class
    {
        try
        {
            var parsed = JsonSerializer.Deserialize<T>(File.ReadAllText(file), JsonOptions);
            if (parsed is not null) { value = parsed; return true; }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException or NotSupportedException) { }
        value = null!;
        return false;
    }

    private static string SetAsideDamagedFile(string file)
    {
        var target = Path.Combine(Path.GetDirectoryName(file)!, $"{Path.GetFileNameWithoutExtension(file)}.unreadable-{DateTime.Now:yyyyMMdd-HHmmss}.json");
        try { File.Move(file, target); return target; }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return file; }
    }
}
