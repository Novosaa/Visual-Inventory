using VisualInventory.Models;
using VisualInventory.Services;

// Exercises every file-changing rule against a throwaway test folder.
if (args.Length != 1) { Console.Error.WriteLine("Usage: VisualInventory.Tests <empty-test-folder>"); return 2; }

var testRoot = Path.GetFullPath(args[0]);
if (Directory.Exists(testRoot)) Directory.Delete(testRoot, recursive: true);
var projectRoot = Path.Combine(testRoot, "My Project");
var outside = Path.Combine(testRoot, "outside");
Directory.CreateDirectory(projectRoot);
Directory.CreateDirectory(outside);

var failures = new List<string>();
void Check(bool ok, string message) { if (!ok) failures.Add(message); }

var paths = new ProjectPaths(projectRoot);
var log = new ActivityLog(paths);
var library = new LibraryService(paths, log);
var store = new StateStore(paths);
var scanner = new ProjectScanner();

Check(!paths.LibraryExists, "Library should not exist before it is created.");
Directory.CreateDirectory(paths.LibraryPath);
Check(paths.DefaultProjectName == "My Project", "Project name should come from the folder name.");

// --- categories
var ads = library.CreateCategory("4-Ads");
var adsBlank = library.CreateCategory("4-Ads-Blank");
var covers = library.CreateCategory("1-Card Covers");
Check(Directory.Exists(ads) && Directory.Exists(covers), "Categories were not created.");
foreach (var bad in new[] { "", "  ", "a/b", "a\\b", "..", "CON", ".hidden", "x:y" })
{
    try { library.CreateCategory(bad); failures.Add($"Bad category name was accepted: '{bad}'"); }
    catch (Exception ex) when (ex is InvalidDataException or IOException) { }
}
try { library.CreateCategory("4-Ads"); failures.Add("Duplicate category was accepted."); } catch (IOException) { }

// --- copy in (originals untouched)
var picture = Path.Combine(outside, "card-front.png");
File.WriteAllBytes(picture, [137, 80, 78, 71, 1, 2, 3]);
var pdf = Path.Combine(outside, "stocklist.pdf");
File.WriteAllText(pdf, "pdf placeholder");
var folder = Path.Combine(outside, "Bundle");
Directory.CreateDirectory(Path.Combine(folder, "inner"));
File.WriteAllText(Path.Combine(folder, "inner", "a.txt"), "a");
File.WriteAllText(Path.Combine(folder, "notes.txt"), "Folder note text");
File.WriteAllBytes(Path.Combine(folder, "cover.jpg"), [1, 2]);

var result = library.ImportCopies([picture, pdf, folder, Path.Combine(outside, "missing.png")], ads);
Check(result.Copied.Count == 3, $"Expected 3 copies, got {result.Copied.Count}.");
Check(result.Failed.Count == 1, "Missing file should be reported, not crash.");
Check(File.Exists(picture) && File.Exists(pdf) && Directory.Exists(folder), "Originals must stay where they were.");
Check(File.Exists(Path.Combine(ads, "card-front.png")), "Copied picture missing.");
Check(File.Exists(Path.Combine(ads, "Bundle", "inner", "a.txt")), "Copied folder contents missing.");

var again = library.ImportCopies([picture], ads);
Check(File.Exists(Path.Combine(ads, "card-front (2).png")), "Name clash should create a numbered copy, never overwrite.");

// --- refuse anything outside the Library or into itself
try { library.ImportCopies([picture], outside); failures.Add("Copy into a folder outside the Library was allowed."); } catch (UnauthorizedAccessException) { }
try { library.ImportCopies([picture], paths.LibraryPath); failures.Add("Copy into the top of the Library was allowed."); } catch (IOException) { }
var self = library.ImportCopies([ads], Path.Combine(ads, "Bundle"));
Check(self.Failed.Count == 1, "Copying a folder into itself must be refused.");
try { library.MoveToCategory(picture, covers); failures.Add("Moving a file from outside the Library was allowed."); } catch (UnauthorizedAccessException) { }
try { library.MoveToCategory(Path.Combine(ads, "card-front.png"), outside); failures.Add("Moving out of the Library was allowed."); } catch (UnauthorizedAccessException) { }

// --- scan
File.WriteAllText(Path.Combine(paths.LibraryPath, "loose.txt"), "loose");
var snapshot = scanner.Scan(paths.LibraryPath);
Check(snapshot.Sections.Select(s => s.Name).SequenceEqual(["1-Card Covers", "4-Ads", "4-Ads-Blank", "Unsorted"]), "Categories should be the real folders plus Unsorted for loose files: " + string.Join(", ", snapshot.Sections.Select(s => s.Name)));
var png = snapshot.Items.Single(i => i.FileName == "card-front.png");
Check(png.HasPreview && png.TypeLabel == "PNG", "PNG should have a picture preview.");
var pdfItem = snapshot.Items.Single(i => i.FileName == "stocklist.pdf");
Check(!pdfItem.HasPreview && pdfItem.TypeLabel == "PDF", "PDF should show its type label, not a picture.");
var bundle = snapshot.Items.Single(i => i.FileName == "Bundle");
Check(bundle.IsDirectory && bundle.HasPreview && bundle.Note == "Folder note text", "Folder should use its own picture and note.");
Check(png.Id == "stored:4-ads-card-front-png", "IDs must match the old app's scheme so statuses can be brought across: " + png.Id);

// --- statuses save, survive a move and a category rename
png.Status = Statuses.Ready;
pdfItem.Status = Statuses.InProgress;
var state = store.LoadStatuses();
store.SaveStatuses(snapshot, state);
Check(File.Exists(paths.StateFile), "Statuses were not saved inside Inventory Data.");

var movedPath = library.MoveToCategory(png.PrimaryPath, covers);
StateStore.MoveEntry(state, png.Id, ProjectScanner.MakeId(Path.GetRelativePath(paths.LibraryPath, movedPath)));
store.WriteStatuses(state);

var adsItems = scanner.Scan(paths.LibraryPath).Items.Where(i => i.Section == "4-Ads").ToList();
var renamed = library.RenameCategory(ads, "4 Ads Final");
foreach (var item in adsItems)
{
    var inside = Path.GetRelativePath(ads, item.PrimaryPath);
    StateStore.MoveEntry(state, item.Id, ProjectScanner.MakeId(Path.GetRelativePath(paths.LibraryPath, Path.Combine(renamed, inside))));
}
store.WriteStatuses(state);

var reread = scanner.Scan(paths.LibraryPath);
var fresh = store.LoadStatuses();
store.Apply(reread, fresh);
Check(reread.Items.Single(i => i.FileName == "card-front.png").Status == Statuses.Ready, "Status was lost when the item was moved.");
Check(reread.Items.Single(i => i.FileName == "stocklist.pdf").Status == Statuses.InProgress, "Status was lost when the category was renamed.");
Check(File.Exists(paths.StateBackupFile), "A backup of the statuses should be kept.");

// --- case-only rename
var caseRenamed = library.RenameCategory(renamed, "4 ADS FINAL");
Check(Directory.Exists(caseRenamed) && Path.GetFileName(caseRenamed) == "4 ADS FINAL", "Case-only rename failed.");

// --- damaged status file is set aside, backup used
File.WriteAllText(paths.StateFile, "{ this is not valid json");
var recovered = store.LoadStatuses();
Check(store.LoadWarning is not null, "A damaged statuses file should produce a warning.");
Check(recovered.Items.Count > 0, "The backup should be used when the statuses file is damaged.");
Check(Directory.GetFiles(paths.DataPath, "statuses.unreadable-*.json").Length == 1, "The damaged file should be kept, not overwritten.");

// --- nothing was ever deleted outside, log exists
Check(File.Exists(picture) && File.Exists(pdf), "Originals outside the Library were changed.");
Check(File.Exists(paths.ActivityLogFile) && File.ReadAllText(paths.ActivityLogFile).Contains("MOVE"), "Activity log is missing entries.");

// --- open policy
Check(FileOpenPolicy.CanOpenDirectly(Path.Combine(outside, "x.pdf")), "PDF should open.");
foreach (var risky in new[] { "x.exe", "x.bat", "x.cmd", "x.ps1", "x.vbs", "x.js", "x.lnk", "x.msi", "x.scr", "x.hta", "x.url", "x.reg", "noextension", "x.pdf.exe" })
    Check(!FileOpenPolicy.CanOpenDirectly(Path.Combine(outside, risky)), $"{risky} must not be opened directly.");

// --- settings and window placement
store.SaveSettings(new ProjectSettings { Name = "Side Eye Series" });
Check(store.LoadSettings().Name == "Side Eye Series", "Project name was not saved.");
store.SaveWindow(new WindowPlacement { Left = 10, Top = 20, Width = 1000, Height = 700 });
Check(store.LoadWindow()?.Width == 1000, "Window size was not saved.");

if (failures.Count == 0) { Console.WriteLine("VISUAL INVENTORY TESTS: PASS"); return 0; }
foreach (var failure in failures) Console.Error.WriteLine("FAIL: " + failure);
Console.Error.WriteLine("VISUAL INVENTORY TESTS: FAIL");
return 1;
