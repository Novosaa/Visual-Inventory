using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace VisualInventory.Models;

public static class Statuses
{
    public const string NotStarted = "Not started";
    public const string InProgress = "In progress";
    public const string NeedsReview = "Needs review";
    public const string Ready = "Ready";
    public static readonly IReadOnlyList<string> All = [NotStarted, InProgress, NeedsReview, Ready];
}

public sealed class WorkspaceSnapshot
{
    public required string LibraryPath { get; init; }
    public DateTime ScannedAt { get; init; } = DateTime.Now;
    public int SourceFileCount { get; set; }
    public List<WorkspaceItem> Items { get; } = [];
    public List<SectionSummary> Sections { get; } = [];
}

public sealed class SectionSummary
{
    public required string Name { get; init; }
    public required string Accent { get; init; }
    /// <summary>Real folder for this category, or null for the virtual "Unsorted" group of loose files.</summary>
    public string? FolderPath { get; init; }
    public int ItemCount { get; init; }
    public int NeedsAttentionCount { get; init; }
    public bool IsRealFolder => FolderPath is not null;
    public int ReadyCount => Math.Max(0, ItemCount - NeedsAttentionCount);
    public string CountText => $"{ItemCount} item{(ItemCount == 1 ? string.Empty : "s")}";
    public string ProgressText => ItemCount == 0 ? "Empty" : $"{ReadyCount} ready · {NeedsAttentionCount} to do";
}

public sealed class WorkspaceItem : INotifyPropertyChanged
{
    private string _status = Statuses.NotStarted;
    private bool _isSelected;

    public required string Id { get; init; }
    public required string Section { get; init; }
    public required string Title { get; init; }
    public required string PrimaryPath { get; init; }
    public required string RelativePath { get; init; }
    public string LibraryLocation => "Library" + Path.DirectorySeparatorChar + RelativePath;
    public string FileName { get; init; } = string.Empty;
    public string Kind { get; init; } = "File";
    /// <summary>Short label shown when there is no picture, e.g. "PDF", "HTML", "FOLDER".</summary>
    public string TypeLabel { get; init; } = "FILE";
    public string? PreviewPath { get; init; }
    public bool HasPreview => PreviewPath is not null;
    public bool IsDirectory { get; init; }
    public int SourceFileCount { get; init; } = 1;
    public string? Note { get; init; }
    public bool HasNote => !string.IsNullOrWhiteSpace(Note);

    public string Status
    {
        get => _status;
        set
        {
            // Ignore blanks a list control can send while it is being switched to another item.
            if (value is null || !Statuses.All.Contains(value) || _status == value) return;
            _status = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(StatusAccent));
            OnPropertyChanged(nameof(NeedsAttention));
        }
    }

    public bool IsSelected
    {
        get => _isSelected;
        set { if (_isSelected == value) return; _isSelected = value; OnPropertyChanged(); }
    }

    public bool NeedsAttention => Status != Statuses.Ready;

    public string StatusAccent => Status switch
    {
        Statuses.Ready => "#A8E95C",
        Statuses.InProgress => "#FFE14A",
        Statuses.NeedsReview => "#FF8A65",
        _ => "#E8E1D8"
    };

    public string SourceCountText => IsDirectory
        ? $"Folder · {SourceFileCount} file{(SourceFileCount == 1 ? string.Empty : "s")}"
        : Kind;

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

public sealed class ItemState
{
    public string Status { get; set; } = Statuses.NotStarted;
}

public sealed class WorkspaceState
{
    public int Version { get; set; } = 2;
    public Dictionary<string, ItemState> Items { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class ProjectSettings
{
    public string? Name { get; set; }
}

public sealed class WindowPlacement
{
    public double Left { get; set; }
    public double Top { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }
    public bool Maximized { get; set; }
    public double DetailsWidth { get; set; } = 330;
    public bool DetailsVisible { get; set; } = true;
}

public sealed class ImportResult
{
    public List<string> Copied { get; } = [];
    public List<string> Failed { get; } = [];
}
