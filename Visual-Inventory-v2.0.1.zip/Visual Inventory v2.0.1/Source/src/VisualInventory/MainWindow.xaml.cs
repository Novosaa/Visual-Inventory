using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using Microsoft.Win32;
using VisualInventory.Models;
using VisualInventory.Services;
using VisualInventory.Views;

namespace VisualInventory;

public partial class MainWindow : Window, INotifyPropertyChanged
{
    private const string OverviewName = "Overview";
    private static readonly string[] Filters = ["All items", "Still to do", "Ready"];

    private readonly ProjectPaths _paths = App.Paths;
    private readonly ProjectScanner _scanner = new();
    private readonly StateStore _store;
    private readonly LibraryService _library;
    private readonly ActivityLog _log;
    private readonly WorkspaceState _state;
    private readonly ProjectSettings _settings;
    private WindowPlacement _placement;
    private WorkspaceSnapshot? _snapshot;
    private WorkspaceItem? _selectedItem;
    private string _currentSection = OverviewName;
    private bool _suppressStatusSave;

    private string _pageTitle = string.Empty;
    private string _pageSubtitle = string.Empty;
    private string _visibleCountText = string.Empty;
    private string _lastScanText = string.Empty;
    private int _totalInventoryItems, _readyItems, _openItems;

    public ObservableCollection<SectionSummary> DashboardSections { get; } = [];
    public ObservableCollection<WorkspaceItem> VisibleItems { get; } = [];
    public ObservableCollection<WorkspaceItem> AttentionItems { get; } = [];
    public ObservableCollection<SectionSummary> MoveTargets { get; } = [];
    public IReadOnlyList<string> StatusOptions => Statuses.All;
    public IReadOnlyList<string> FilterOptions => Filters;

    public string ProjectName => string.IsNullOrWhiteSpace(_settings.Name) ? _paths.DefaultProjectName : _settings.Name!;
    public string WindowTitle => $"{ProjectName} — Visual Inventory";
    public string LibraryPathText => _paths.LibraryPath;

    public WorkspaceItem? SelectedItem
    {
        get => _selectedItem;
        private set
        {
            if (ReferenceEquals(_selectedItem, value)) return;
            if (_selectedItem is not null) _selectedItem.IsSelected = false;
            _selectedItem = value;
            if (_selectedItem is not null) _selectedItem.IsSelected = true;
            OnPropertyChanged();
            RefreshMoveTargets();
        }
    }

    public string PageTitle { get => _pageTitle; private set { _pageTitle = value; OnPropertyChanged(); } }
    public string PageSubtitle { get => _pageSubtitle; private set { _pageSubtitle = value; OnPropertyChanged(); } }
    public string VisibleCountText { get => _visibleCountText; private set { _visibleCountText = value; OnPropertyChanged(); } }
    public string LastScanText { get => _lastScanText; private set { _lastScanText = value; OnPropertyChanged(); } }
    public int TotalInventoryItems { get => _totalInventoryItems; private set { _totalInventoryItems = value; OnPropertyChanged(); } }
    public int ReadyItems { get => _readyItems; private set { _readyItems = value; OnPropertyChanged(); } }
    public int OpenItems { get => _openItems; private set { _openItems = value; OnPropertyChanged(); } }

    public MainWindow()
    {
        _store = new StateStore(_paths);
        _log = new ActivityLog(_paths);
        _library = new LibraryService(_paths, _log);
        _settings = _store.LoadSettings();
        _state = _store.LoadStatuses();
        _placement = _store.LoadWindow() ?? new WindowPlacement();

        InitializeComponent();
        DataContext = this;
        FitWindowToScreen();
        ApplyDetailsVisibility();

        Loaded += (_, _) =>
        {
            if (_store.LoadWarning is not null)
                MessageBox.Show(this, _store.LoadWarning, "Statuses", MessageBoxButton.OK, MessageBoxImage.Warning);
            LoadProject(null);
        };
    }

    // ---------------------------------------------------------------- window size and position

    /// <summary>Uses the remembered size and position if it is still on screen; otherwise fits the screen.</summary>
    private void FitWindowToScreen()
    {
        var work = SystemParameters.WorkArea;
        MinWidth = Math.Min(900, work.Width);
        MinHeight = Math.Min(560, work.Height);

        if (_placement.Width >= MinWidth && _placement.Height >= MinHeight && IsVisibleOnScreens(_placement))
        {
            Left = _placement.Left;
            Top = _placement.Top;
            Width = _placement.Width;
            Height = _placement.Height;
            if (_placement.Maximized) WindowState = WindowState.Maximized;
            return;
        }

        Width = Math.Max(MinWidth, Math.Min(1480, work.Width * 0.94));
        Height = Math.Max(MinHeight, Math.Min(900, work.Height * 0.94));
        Left = work.Left + (work.Width - Width) / 2;
        Top = work.Top + (work.Height - Height) / 2;
    }

    private static bool IsVisibleOnScreens(WindowPlacement p)
    {
        var left = SystemParameters.VirtualScreenLeft;
        var top = SystemParameters.VirtualScreenTop;
        var right = left + SystemParameters.VirtualScreenWidth;
        var bottom = top + SystemParameters.VirtualScreenHeight;
        return p.Width <= SystemParameters.VirtualScreenWidth + 16
               && p.Height <= SystemParameters.VirtualScreenHeight + 16
               && p.Left + p.Width - 120 > left && p.Left + 120 < right   // at least 120px across is visible
               && p.Top >= top - 8 && p.Top + 60 < bottom;                 // the title bar is reachable
    }

    private void Window_Closing(object? sender, CancelEventArgs e)
    {
        var bounds = WindowState == WindowState.Normal ? new Rect(Left, Top, Width, Height) : RestoreBounds;
        _placement.Left = bounds.Left;
        _placement.Top = bounds.Top;
        _placement.Width = bounds.Width;
        _placement.Height = bounds.Height;
        _placement.Maximized = WindowState == WindowState.Maximized;
        _store.SaveWindow(_placement);
    }

    private void DetailsToggle_Click(object sender, RoutedEventArgs e)
    {
        _placement.DetailsVisible = !_placement.DetailsVisible;
        ApplyDetailsVisibility();
    }

    private void ApplyDetailsVisibility()
    {
        var visible = _placement.DetailsVisible;
        DetailsPanel.Visibility = visible ? Visibility.Visible : Visibility.Collapsed;
        DetailsSplitter.Visibility = visible ? Visibility.Visible : Visibility.Collapsed;
        DetailsColumn.MinWidth = visible ? 260 : 0;
        DetailsColumn.Width = visible ? new GridLength(Math.Clamp(_placement.DetailsWidth, 260, 700)) : new GridLength(0);
        DetailsToggle.Content = visible ? "Hide details" : "Show details";
    }

    private void DetailsSplitter_DragCompleted(object sender, DragCompletedEventArgs e)
    {
        if (_placement.DetailsVisible) _placement.DetailsWidth = DetailsColumn.ActualWidth;
    }

    // ---------------------------------------------------------------- loading

    private void LoadProject(string? keepSection)
    {
        if (!_paths.LibraryExists)
        {
            _snapshot = null;
            SelectedItem = null;
            DashboardSections.Clear();
            MissingLibraryView.Visibility = Visibility.Visible;
            DashboardView.Visibility = Visibility.Collapsed;
            SectionView.Visibility = Visibility.Collapsed;
            PageTitle = ProjectName;
            PageSubtitle = "No Library folder yet";
            return;
        }

        try
        {
            Mouse.OverrideCursor = Cursors.Wait;
            var previousSelection = SelectedItem?.PrimaryPath;
            var snapshot = _scanner.Scan(_paths.LibraryPath);
            _suppressStatusSave = true;
            _store.Apply(snapshot, _state);
            _suppressStatusSave = false;
            foreach (var item in snapshot.Items) item.PropertyChanged += Item_PropertyChanged;
            _snapshot = snapshot;
            SelectedItem = null;
            RefreshDashboard();

            MissingLibraryView.Visibility = Visibility.Collapsed;
            if (keepSection is not null && keepSection != OverviewName && FindSection(keepSection) is not null)
            {
                ShowSection(keepSection, keepFilters: true);
                var again = previousSelection is null ? null : VisibleItems.FirstOrDefault(i => PathRules.SamePath(i.PrimaryPath, previousSelection));
                if (again is not null) SelectedItem = again;
            }
            else
            {
                ShowOverview();
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            MessageBox.Show(this, "The Library folder could not be read.\n\n" + ex.Message, "Visual Inventory", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally
        {
            _suppressStatusSave = false;
            Mouse.OverrideCursor = null;
        }
    }

    private void Refresh_Click(object sender, RoutedEventArgs e) => LoadProject(_currentSection);

    private void CreateLibrary_Click(object sender, RoutedEventArgs e)
    {
        TryFileAction(() =>
        {
            Directory.CreateDirectory(_paths.LibraryPath);
            _log.Write("NEW LIBRARY", _paths.LibraryPath);
            LoadProject(null);
        });
    }

    // ---------------------------------------------------------------- navigation

    private SectionSummary? FindSection(string name) =>
        _snapshot?.Sections.FirstOrDefault(s => s.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

    private void Navigation_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: string section }) return;
        if (section == OverviewName) ShowOverview(); else ShowSection(section, keepFilters: false);
    }

    private void DashboardCard_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: string section }) ShowSection(section, keepFilters: false);
    }

    private void AttentionItem_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { DataContext: WorkspaceItem item }) return;
        ShowSection(item.Section, keepFilters: false);
        SelectedItem = VisibleItems.Contains(item) ? item : SelectedItem;
    }

    private void ShowOverview()
    {
        if (_snapshot is null) { LoadProject(null); return; }
        _currentSection = OverviewName;
        DashboardView.Visibility = Visibility.Visible;
        SectionView.Visibility = Visibility.Collapsed;
        PageTitle = ProjectName;
        PageSubtitle = $"{_snapshot.Items.Count} items in {_snapshot.Sections.Count} categories";
        SelectedItem = null;
        EmptyLibraryPanel.Visibility = _snapshot.Sections.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    private void ShowSection(string section, bool keepFilters)
    {
        if (_snapshot is null) return;
        var summary = FindSection(section);
        if (summary is null) { ShowOverview(); return; }
        _currentSection = summary.Name;
        DashboardView.Visibility = Visibility.Collapsed;
        SectionView.Visibility = Visibility.Visible;
        PageTitle = summary.Name;
        PageSubtitle = summary.IsRealFolder
            ? $"Library{Path.DirectorySeparatorChar}{summary.Name}"
            : "Loose files at the top of the Library folder";
        if (!keepFilters)
        {
            SearchBox.Text = string.Empty;
            StatusFilterBox.SelectedIndex = 0;
            ItemsScroller.ScrollToTop();
        }
        ApplyFilter();
    }

    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_snapshot is not null && _currentSection != OverviewName) ApplyFilter();
    }

    private void StatusFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_snapshot is not null && _currentSection != OverviewName) ApplyFilter();
    }

    private void ApplyFilter()
    {
        if (_snapshot is null || SearchBox is null || StatusFilterBox is null) return;
        var query = SearchBox.Text.Trim();
        var filter = StatusFilterBox.SelectedItem as string ?? Filters[0];
        var matches = _snapshot.Items
            .Where(item => item.Section.Equals(_currentSection, StringComparison.OrdinalIgnoreCase))
            .Where(item => query.Length == 0
                           || item.Title.Contains(query, StringComparison.OrdinalIgnoreCase)
                           || item.FileName.Contains(query, StringComparison.OrdinalIgnoreCase)
                           || item.TypeLabel.Contains(query, StringComparison.OrdinalIgnoreCase)
                           || (item.Note?.Contains(query, StringComparison.OrdinalIgnoreCase) ?? false))
            .Where(item => filter switch
            {
                "Still to do" => item.NeedsAttention,
                "Ready" => !item.NeedsAttention,
                _ => true
            })
            .OrderBy(item => item.Title, StringComparer.CurrentCultureIgnoreCase)
            .ToList();

        var keep = SelectedItem;
        VisibleItems.Clear();
        foreach (var item in matches) VisibleItems.Add(item);
        SelectedItem = keep is not null && matches.Contains(keep) ? keep : VisibleItems.FirstOrDefault();
        VisibleCountText = matches.Count == 1 ? "1 shown" : $"{matches.Count} shown";
    }

    private void RefreshDashboard()
    {
        if (_snapshot is null) return;
        var rebuilt = _snapshot.Sections.Select(section =>
        {
            var items = _snapshot.Items.Where(i => i.Section.Equals(section.Name, StringComparison.OrdinalIgnoreCase)).ToList();
            return new SectionSummary
            {
                Name = section.Name,
                Accent = section.Accent,
                FolderPath = section.FolderPath,
                ItemCount = items.Count,
                NeedsAttentionCount = items.Count(i => i.NeedsAttention)
            };
        }).ToList();

        // Only rebuild the sidebar when the categories themselves changed, so it doesn't jump while you work.
        var sameNames = rebuilt.Select(s => s.Name).SequenceEqual(DashboardSections.Select(s => s.Name));
        if (sameNames)
            for (var i = 0; i < rebuilt.Count; i++) DashboardSections[i] = rebuilt[i];
        else
        {
            DashboardSections.Clear();
            foreach (var section in rebuilt) DashboardSections.Add(section);
        }

        TotalInventoryItems = _snapshot.Items.Count;
        ReadyItems = _snapshot.Items.Count(i => !i.NeedsAttention);
        OpenItems = TotalInventoryItems - ReadyItems;
        LastScanText = $"Read {_snapshot.ScannedAt:g}";

        AttentionItems.Clear();
        foreach (var item in _snapshot.Items.Where(i => i.NeedsAttention)
                     .OrderBy(i => i.Status == Statuses.InProgress ? 0 : i.Status == Statuses.NeedsReview ? 1 : 2)
                     .ThenBy(i => i.Section, StringComparer.CurrentCultureIgnoreCase)
                     .ThenBy(i => i.Title, StringComparer.CurrentCultureIgnoreCase)
                     .Take(8))
            AttentionItems.Add(item);

        RefreshMoveTargets();
    }

    private void RefreshMoveTargets()
    {
        MoveTargets.Clear();
        if (_snapshot is null || SelectedItem is null) return;
        foreach (var section in _snapshot.Sections.Where(s => s.IsRealFolder && !s.Name.Equals(SelectedItem.Section, StringComparison.OrdinalIgnoreCase)))
            MoveTargets.Add(section);
    }

    // ---------------------------------------------------------------- statuses

    private void Item_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (_suppressStatusSave || e.PropertyName != nameof(WorkspaceItem.Status)) return;
        SaveStatuses();
        RefreshDashboard();
    }

    private void SaveStatuses()
    {
        if (_snapshot is null) return;
        try { _store.SaveStatuses(_snapshot, _state); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            MessageBox.Show(this, "The status could not be saved. If this project is on a read-only disc or locked USB, statuses can't be saved.\n\n" + ex.Message,
                "Status not saved", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void SetStatus(WorkspaceItem item, string status) => item.Status = status;

    // ---------------------------------------------------------------- items

    private void ItemCard_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { DataContext: WorkspaceItem item }) SelectedItem = item;
    }

    private void ItemCard_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (sender is Button { DataContext: WorkspaceItem item }) { SelectedItem = item; OpenSafely(item.PrimaryPath); e.Handled = true; }
    }

    private void OpenItem_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedItem is not null) OpenSafely(SelectedItem.PrimaryPath);
    }

    private void ShowInExplorer_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedItem is not null) ShowInExplorer(SelectedItem.PrimaryPath);
    }

    private void MoveItem_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedItem is null) return;
        if (MoveCategoryBox.SelectedItem is not SectionSummary destination)
        {
            MessageBox.Show(this, "Choose the category to move it into first.", "Move", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        MoveItem(SelectedItem, destination);
    }

    private void MoveItem(WorkspaceItem item, SectionSummary destination)
    {
        if (destination.FolderPath is null) return;
        TryFileAction(() =>
        {
            var newPath = _library.MoveToCategory(item.PrimaryPath, destination.FolderPath);
            StateStore.MoveEntry(_state, item.Id, ProjectScanner.MakeId(Path.GetRelativePath(_paths.LibraryPath, newPath)));
            _store.WriteStatuses(_state);
            LoadProject(_currentSection);
        });
    }

    /// <summary>Opens documents, images and folders. Anything that could run a program is shown in Explorer instead.</summary>
    private void OpenSafely(string path)
    {
        if (!File.Exists(path) && !Directory.Exists(path))
        {
            MessageBox.Show(this, "That item is no longer there. Press Refresh.", "Not found", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        if (!FileOpenPolicy.CanOpenDirectly(path))
        {
            MessageBox.Show(this,
                $"\"{Path.GetFileName(path)}\" is a type of file that could run a program, so Visual Inventory won't open it.\n\nIt will be shown in Explorer instead.",
                "Not opened", MessageBoxButton.OK, MessageBoxImage.Information);
            ShowInExplorer(path);
            return;
        }
        try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); }
        catch (Exception ex) when (ex is Win32Exception or InvalidOperationException)
        {
            MessageBox.Show(this, "Windows has no program set to open this kind of file.\n\n" + ex.Message, "Not opened", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private static void ShowInExplorer(string path)
    {
        try
        {
            if (File.Exists(path))
                Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{path}\"") { UseShellExecute = false });
            else if (Directory.Exists(path))
                Process.Start(new ProcessStartInfo("explorer.exe", $"\"{path}\"") { UseShellExecute = false });
        }
        catch (Exception ex) when (ex is Win32Exception or InvalidOperationException) { }
    }

    private static void CopyText(string text)
    {
        try { Clipboard.SetText(text); }
        catch (Exception) { /* clipboard busy in another program; nothing to do */ }
    }

    // ---------------------------------------------------------------- adding files (always copies)

    private void AddFiles_Click(object sender, RoutedEventArgs e)
    {
        var category = CurrentRealCategory();
        if (category is null) return;
        var dialog = new OpenFileDialog { Title = $"Choose files to copy into {category.Name}", Multiselect = true, CheckFileExists = true };
        if (dialog.ShowDialog(this) == true) ImportCopies(dialog.FileNames, category);
    }

    private void AddFolder_Click(object sender, RoutedEventArgs e)
    {
        var category = CurrentRealCategory();
        if (category is null) return;
        var dialog = new OpenFolderDialog { Title = $"Choose folders to copy into {category.Name}", Multiselect = true };
        if (dialog.ShowDialog(this) == true) ImportCopies(dialog.FolderNames, category);
    }

    private void Window_Drop(object sender, DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(DataFormats.FileDrop) || e.Data.GetData(DataFormats.FileDrop) is not string[] dropped || dropped.Length == 0) return;
        var category = CurrentRealCategory();
        if (category is null) return;
        ImportCopies(dropped, category); // always a copy; originals stay where they are
    }

    private SectionSummary? CurrentRealCategory()
    {
        var section = _currentSection == OverviewName ? null : FindSection(_currentSection);
        if (section?.FolderPath is not null) return section;
        MessageBox.Show(this, "Open a category first (from the list on the left), then add files to it.", "Choose a category", MessageBoxButton.OK, MessageBoxImage.Information);
        return null;
    }

    private void ImportCopies(IEnumerable<string> sources, SectionSummary category)
    {
        TryFileAction(() =>
        {
            Mouse.OverrideCursor = Cursors.Wait;
            ImportResult result;
            try { result = _library.ImportCopies(sources, category.FolderPath!); }
            finally { Mouse.OverrideCursor = null; }
            LoadProject(category.Name);
            if (result.Failed.Count > 0)
            {
                var list = string.Join("\n", result.Failed.Take(12)) + (result.Failed.Count > 12 ? $"\n…and {result.Failed.Count - 12} more" : "");
                MessageBox.Show(this, $"Copied {result.Copied.Count}. These were not copied:\n\n{list}", "Some items not copied", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        });
    }

    // ---------------------------------------------------------------- categories and project

    private void NewCategory_Click(object sender, RoutedEventArgs e) => NewCategory();

    private void NewCategory()
    {
        if (!_paths.LibraryExists) { LoadProject(null); return; }
        var name = TextPrompt.Ask(this, "New category", "Name for the new category (it becomes a folder inside Library):", string.Empty);
        if (name is null) return;
        TryFileAction(() =>
        {
            var folder = _library.CreateCategory(name);
            LoadProject(Path.GetFileName(folder));
        });
    }

    private void RenameCategory(SectionSummary section)
    {
        if (_snapshot is null || section.FolderPath is null)
        {
            MessageBox.Show(this, "\"Unsorted\" holds loose files at the top of the Library. It isn't a folder, so it can't be renamed.", "Rename", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var newName = TextPrompt.Ask(this, "Rename category", "New name for this category:", section.Name);
        if (newName is null || newName == section.Name) return;

        var items = _snapshot.Items.Where(i => i.Section.Equals(section.Name, StringComparison.OrdinalIgnoreCase)).ToList();
        var stayInSection = _currentSection.Equals(section.Name, StringComparison.OrdinalIgnoreCase);
        TryFileAction(() =>
        {
            var newFolder = _library.RenameCategory(section.FolderPath, newName);
            foreach (var item in items)
            {
                var inside = Path.GetRelativePath(section.FolderPath, item.PrimaryPath);
                var newRelative = Path.GetRelativePath(_paths.LibraryPath, Path.Combine(newFolder, inside));
                StateStore.MoveEntry(_state, item.Id, ProjectScanner.MakeId(newRelative));
            }
            _store.WriteStatuses(_state);
            LoadProject(stayInSection ? Path.GetFileName(newFolder) : _currentSection);
        });
    }

    private void RenameProject()
    {
        var name = TextPrompt.Ask(this, "Rename project", "Name shown for this project (the folder itself is not renamed):", ProjectName);
        if (string.IsNullOrWhiteSpace(name)) return;
        _settings.Name = name;
        if (!TrySaveSettings()) return;
        OnPropertyChanged(nameof(ProjectName));
        OnPropertyChanged(nameof(WindowTitle));
        if (_currentSection == OverviewName) PageTitle = ProjectName;
    }

    private bool TrySaveSettings()
    {
        try { _store.SaveSettings(_settings); return true; }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            MessageBox.Show(this, "Settings could not be saved.\n\n" + ex.Message, "Visual Inventory", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }
    }

    private void OpenLibraryFolder_Click(object sender, RoutedEventArgs e) => ShowInExplorer(_paths.LibraryPath);

    // ---------------------------------------------------------------- right-click menus

    private void ItemCard_RightClick(object sender, MouseButtonEventArgs e)
    {
        if (sender is not Button { DataContext: WorkspaceItem item } button) return;
        e.Handled = true;
        SelectedItem = item;

        var menu = new ContextMenu();
        menu.Items.Add(MenuEntry("Open", () => OpenSafely(item.PrimaryPath)));
        menu.Items.Add(MenuEntry("Show in Explorer", () => ShowInExplorer(item.PrimaryPath)));
        menu.Items.Add(new Separator());

        var status = new MenuItem { Header = "Set status" };
        foreach (var option in Statuses.All)
        {
            var entry = MenuEntry(option, () => SetStatus(item, option));
            entry.IsCheckable = false;
            entry.IsChecked = item.Status == option;
            status.Items.Add(entry);
        }
        menu.Items.Add(status);

        var move = new MenuItem { Header = "Move to" };
        foreach (var section in _snapshot?.Sections.Where(s => s.IsRealFolder && !s.Name.Equals(item.Section, StringComparison.OrdinalIgnoreCase)) ?? Enumerable.Empty<SectionSummary>())
        {
            var target = section;
            move.Items.Add(MenuEntry(target.Name, () => MoveItem(item, target)));
        }
        move.IsEnabled = move.Items.Count > 0;
        menu.Items.Add(move);

        menu.Items.Add(new Separator());
        menu.Items.Add(MenuEntry("Copy file name", () => CopyText(item.FileName)));
        menu.Items.Add(MenuEntry("Copy full path", () => CopyText(item.PrimaryPath)));
        ShowMenu(menu, button);
    }

    private void ItemsArea_RightClick(object sender, MouseButtonEventArgs e)
    {
        if (e.Handled) return;
        e.Handled = true;
        var section = FindSection(_currentSection);
        var menu = new ContextMenu();
        menu.Items.Add(MenuEntry("Add files…", () => AddFiles_Click(this, new RoutedEventArgs())));
        menu.Items.Add(MenuEntry("Add folder…", () => AddFolder_Click(this, new RoutedEventArgs())));
        menu.Items.Add(new Separator());
        menu.Items.Add(MenuEntry("Refresh", () => LoadProject(_currentSection), "F5"));
        if (section?.FolderPath is not null)
        {
            menu.Items.Add(MenuEntry("Show category in Explorer", () => ShowInExplorer(section.FolderPath)));
            menu.Items.Add(MenuEntry("Rename category…", () => RenameCategory(section)));
        }
        ShowMenu(menu, (FrameworkElement)sender);
    }

    private void Category_RightClick(object sender, MouseButtonEventArgs e)
    {
        if (sender is not Button { Tag: string name } button) return;
        e.Handled = true;
        var section = FindSection(name);
        if (section is null) return;

        var menu = new ContextMenu();
        menu.Items.Add(MenuEntry("Open category", () => ShowSection(section.Name, keepFilters: false)));
        if (section.FolderPath is not null)
        {
            menu.Items.Add(MenuEntry("Show in Explorer", () => ShowInExplorer(section.FolderPath)));
            menu.Items.Add(MenuEntry("Rename category…", () => RenameCategory(section)));
        }
        menu.Items.Add(new Separator());
        menu.Items.Add(MenuEntry("New category…", NewCategory));
        ShowMenu(menu, button);
    }

    private void Overview_RightClick(object sender, MouseButtonEventArgs e)
    {
        if (e.Handled) return;
        e.Handled = true;
        var menu = new ContextMenu();
        menu.Items.Add(MenuEntry("New category…", NewCategory));
        menu.Items.Add(MenuEntry("Refresh", () => LoadProject(OverviewName), "F5"));
        menu.Items.Add(MenuEntry("Show Library in Explorer", () => ShowInExplorer(_paths.LibraryPath)));
        menu.Items.Add(new Separator());
        menu.Items.Add(MenuEntry("Rename project…", RenameProject));
        ShowMenu(menu, (FrameworkElement)sender);
    }

    private void ProjectHeader_RightClick(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true;
        var menu = new ContextMenu();
        menu.Items.Add(MenuEntry("Rename project…", RenameProject));
        menu.Items.Add(MenuEntry("Show project folder in Explorer", () => ShowInExplorer(_paths.Root)));
        ShowMenu(menu, (FrameworkElement)sender);
    }

    private static MenuItem MenuEntry(string header, Action action, string? gesture = null)
    {
        var item = new MenuItem { Header = header, InputGestureText = gesture ?? string.Empty };
        item.Click += (_, _) => action();
        return item;
    }

    private static void ShowMenu(ContextMenu menu, FrameworkElement target)
    {
        menu.PlacementTarget = target;
        menu.Placement = PlacementMode.MousePoint;
        menu.IsOpen = true;
    }

    // ---------------------------------------------------------------- keyboard

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.F5) { LoadProject(_currentSection); e.Handled = true; return; }
        if (e.Key == Key.F && Keyboard.Modifiers == ModifierKeys.Control && SectionView.Visibility == Visibility.Visible)
        {
            SearchBox.Focus(); SearchBox.SelectAll(); e.Handled = true; return;
        }
        if (e.Key == Key.Escape && SearchBox.IsKeyboardFocusWithin && SearchBox.Text.Length > 0)
        {
            SearchBox.Text = string.Empty; e.Handled = true; return;
        }
        if (e.Key == Key.Enter && SelectedItem is not null && SectionView.Visibility == Visibility.Visible
            && Keyboard.FocusedElement is not TextBox && Keyboard.FocusedElement is not ComboBox && Keyboard.FocusedElement is not ComboBoxItem)
        {
            OpenSafely(SelectedItem.PrimaryPath); e.Handled = true;
        }
    }

    // ---------------------------------------------------------------- helpers

    private void TryFileAction(Action action)
    {
        try { action(); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException or ArgumentException or NotSupportedException)
        {
            Mouse.OverrideCursor = null;
            MessageBox.Show(this, ex.Message, "Not done", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
